package gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Articulo;
import logica.Carta;
import logica.Pedido;

import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.GridLayout;
import javax.swing.SwingConstants;

public class VentanaPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JLabel lbLogo;
	private JLabel lbMcDonalds;
	private JTextField txtPrecioPedido;
	private JSpinner spUnidades;
	private JLabel lbPrecioPedido;
	private JButton btnSiguiente;
	private JButton btCancelar;
	private JButton btAdd;
	private JLabel lbArticulos;
	private JComboBox<Articulo> cbArticulos;
	private JLabel lbUnidades;
	private Carta carta;
	private Pedido pedido;
	private JButton btEliminar;
	private JLabel lbPedido;
	private JScrollPane scllPedido;
	private JTextArea txtPedido;
	private JLabel lbImgProducto;
	private JMenuBar menuBar;
	private JMenu mnPedido;
	private JMenu mnAyuda;
	private JMenuItem mntmNuevo;
	private JMenuItem mntmContenidos;
	private JSeparator separator;
	private JMenuItem mntmSalir;
	private JMenuItem mntmAcercaDe;
	private JPanel panel;
	private JButton btPostres;
	private JButton btHamburger;
	private JButton btBebidas;
	private JButton btComplementos;
	

	
//	public static void main(String[] args) {
//		Carta carta = new Carta();
//		Pedido pedido = new Pedido();
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					VentanaPrincipal frame = new VentanaPrincipal(carta,pedido);
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	
	
	
	/**
	 * Create the frame.
	 */
	public VentanaPrincipal(Carta carta, Pedido pedido) {
		this.carta = carta;
		this.pedido = pedido;
		setResizable(false);
		setTitle("McDonald's Espa\u00F1a");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 470);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLbLogo());
		contentPane.add(getLbMcDonalds());
		contentPane.add(getTxtPrecioPedido());
		contentPane.add(getSpUnidades());
		contentPane.add(getLbPrecioPedido());
		contentPane.add(getBtnSiguiente());
		contentPane.add(getBtCancelar());
		contentPane.add(getBtAdd());
		contentPane.add(getLbArticulos());
		contentPane.add(getCbArticulos());
		contentPane.add(getLbUnidades());
		contentPane.add(getBtEliminar());
		contentPane.add(getLbPedido());
		contentPane.add(getScllPedido());
		contentPane.add(getLbImgProducto());
		contentPane.add(getPanel());
		inicializar();
	}
	
	//reinicia la aplicacion para que lo use mas de un usuario
	public void inicializar() {
		pedido.inicializar(); //equisde
		cbArticulos.setModel(new DefaultComboBoxModel<Articulo>(tipoArticulo("Hamburguesa")));
		getCbArticulos().setSelectedIndex(0); //primer elemento
		getSpUnidades().setValue(1); // 1 unidad
		getTxtPrecioPedido().setText("");
		getLbPrecioPedido().setText("Precio Pedido: "); //vacia
		getBtnSiguiente().setEnabled(false); //desavilita el boton
		getBtCancelar().setEnabled(false);
		actualizarCb();
	}
	
	
	public Pedido getPedido() {
		return pedido;
	}
	
	
	private JLabel getLbLogo() {
		if (lbLogo == null) {
			lbLogo = new JLabel("New label");
			lbLogo.setBounds(200, 11, 150, 147);
			lbLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.png")));
		}
		return lbLogo;
	}
	private JLabel getLbMcDonalds() {
		if (lbMcDonalds == null) {
			lbMcDonalds = new JLabel("McDonald's");
			lbMcDonalds.setBounds(360, 60, 231, 69);
			lbMcDonalds.setFont(new Font("Arial Black", Font.PLAIN, 34));
		}
		return lbMcDonalds;
	}
	private JTextField getTxtPrecioPedido() {
		if (txtPrecioPedido == null) {
			txtPrecioPedido = new JTextField();
			txtPrecioPedido.setFont(new Font("Tahoma", Font.PLAIN, 13));
			txtPrecioPedido.setBounds(490, 297, 86, 30);
			txtPrecioPedido.setEditable(false);
			txtPrecioPedido.setColumns(10);
		}
		return txtPrecioPedido;
	}
	@SuppressWarnings("deprecation")
	private JSpinner getSpUnidades() {
		if (spUnidades == null) {
			spUnidades = new JSpinner();
			spUnidades.setFont(new Font("Tahoma", Font.PLAIN, 13));
			spUnidades.setBounds(490, 217, 72, 30);
			spUnidades.setBackground(Color.WHITE);
			spUnidades.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		}
		return spUnidades;
	}
	private JLabel getLbPrecioPedido() {
		if (lbPrecioPedido == null) {
			lbPrecioPedido = new JLabel("Precio Pedido:");
			lbPrecioPedido.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lbPrecioPedido.setBounds(490, 272, 170, 14);
		}
		return lbPrecioPedido;
	}
	private JButton getBtnSiguiente() {
		if (btnSiguiente == null) {
			btnSiguiente = new JButton("Siguiente");
			btnSiguiente.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btnSiguiente.setMnemonic('S');
			btnSiguiente.setBounds(634, 355, 89, 30);
			btnSiguiente.setEnabled(false);
			btnSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarVentanaRegistro();
				}
			});
			btnSiguiente.setForeground(Color.WHITE);
			btnSiguiente.setBackground(Color.GREEN);
		}
		return btnSiguiente;
	}
	private JButton getBtCancelar() {
		if (btCancelar == null) {
			btCancelar = new JButton("Cancelar");
			btCancelar.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btCancelar.setMnemonic('C');
			btCancelar.setEnabled(false);
			btCancelar.setBounds(733, 355, 89, 30);
			btCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(!pedido.isVacio()) 
						if(confirmarCancelacion())
								inicializar();
				}

				
				
			});
			btCancelar.setForeground(Color.WHITE);
			btCancelar.setBackground(Color.RED);
		}
		return btCancelar;
	}
	
	private boolean confirmarCancelacion() {
		boolean yes = false;
		int resp = JOptionPane.showConfirmDialog(null, "�Est� seguro de cancelar el pedido?", "Aviso.", 0);
		if(resp == JOptionPane.YES_OPTION)
			yes = true;
		return yes;
	}
	
	
	private JButton getBtAdd() {
		if (btAdd == null) {
			btAdd = new JButton("A\u00F1adir");
			btAdd.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btAdd.setBounds(598, 217, 86, 30);
			btAdd.setMnemonic('A');
			btAdd.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					a�adirAPedido();
					btEliminar.setEnabled(true);
				}
			});
			btAdd.setForeground(Color.WHITE);
			btAdd.setBackground(Color.GREEN);
		}
		return btAdd;
	}
	
	
	private JButton getBtEliminar() {
		if (btEliminar == null) {
			btEliminar = new JButton("Eliminar");
			btEliminar.setEnabled(false);
			btEliminar.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btEliminar.setMnemonic('E');
			btEliminar.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					eliminarDePedido();
					if(pedido.getListaPedido( (Articulo) cbArticulos.getSelectedItem()) == null)
						btEliminar.setEnabled(false);
				}

				
			});
			btEliminar.setForeground(Color.WHITE);
			btEliminar.setBackground(Color.GREEN);
			btEliminar.setBounds(696, 217, 86, 31);
		}
		return btEliminar;
	}
	
	private void eliminarDePedido() {
		Articulo articuloSeleccionado = (Articulo) getCbArticulos().getSelectedItem();
		int unidadesEliminar = (int) getSpUnidades().getValue();
		pedido.remove(articuloSeleccionado, unidadesEliminar);
		String precio = String.format("%.2f", pedido.getTotal());
		getTxtPrecioPedido().setText(precio + (" \u20AC"));
		if(pedido.getTotal() == 0) {
			btnSiguiente.setEnabled(false);
			txtPrecioPedido.setText("");
		}
		//descuentos
	}
	
	
	private JLabel getLbArticulos() {
		if (lbArticulos == null) {
			lbArticulos = new JLabel("Articulos:");
			lbArticulos.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lbArticulos.setBounds(200, 192, 86, 14);
			lbArticulos.setLabelFor(getCbArticulos());
			lbArticulos.setDisplayedMnemonic('R');
		}
		return lbArticulos;
	}
	
	private JComboBox<Articulo> getCbArticulos() {
		if (cbArticulos == null) {
			cbArticulos = new JComboBox<Articulo>();
			cbArticulos.setFont(new Font("Tahoma", Font.PLAIN, 13));
			cbArticulos.setBounds(200, 217, 269, 30);
			cbArticulos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					actualizarCb();
				}
			});
			cbArticulos.setModel(new DefaultComboBoxModel<Articulo>(tipoArticulo("Hamburguesa")));
		}
		return cbArticulos;
	}
	
	private void actualizarCb() {
		getSpUnidades().setValue(1);
		if(pedido.getListaPedido( (Articulo) cbArticulos.getSelectedItem()) != null)
			btEliminar.setEnabled(true);
		else btEliminar.setEnabled(false);
		String fotoArticulo = "/img/" + ((Articulo)getCbArticulos().getSelectedItem()).getCodigo() + ".png";
		getLbImgProducto().setIcon(new ImageIcon(VentanaPrincipal.class.getResource(fotoArticulo)));
	}
	
	private JLabel getLbUnidades() {
		if (lbUnidades == null) {
			lbUnidades = new JLabel("Unidades:");
			lbUnidades.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lbUnidades.setBounds(490, 192, 72, 14);
			lbUnidades.setLabelFor(getSpUnidades());
			lbUnidades.setDisplayedMnemonic('U');
		}
		return lbUnidades;
	}
	
	
	private void mostrarVentanaRegistro() {
		VentanaRegistro vRegistro = new VentanaRegistro(this);
		vRegistro.setLocationRelativeTo(this);
		vRegistro.setModal(true);
		vRegistro.setVisible(true);
	}
	
	private void a�adirAPedido() {
		Articulo articuloSeleccionado = (Articulo) getCbArticulos().getSelectedItem();
		int unidadesSolicitadas = (int) getSpUnidades().getValue();
		pedido.add(articuloSeleccionado, unidadesSolicitadas);
		String precio = String.format("%.2f", pedido.getTotal());
		getTxtPrecioPedido().setText(precio + (" \u20AC"));
		if(pedido.getDescuentoAplicado()) {
			lbPrecioPedido.setText("Precio CON el descuento: ");		
		}
		if(!getBtnSiguiente().isEnabled())
			getBtnSiguiente().setEnabled(true);
		if(!getBtCancelar().isEnabled())
			getBtCancelar().setEnabled(true);
	}
	private JLabel getLbPedido() {
		if (lbPedido == null) {
			lbPedido = new JLabel("");
			lbPedido.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					txtPedido.setText(pedido.toString());
					scllPedido.setVisible(true);
					txtPedido.setVisible(true);
					
				}
				@Override
				public void mouseReleased(MouseEvent e) {
					scllPedido.setVisible(false);
					txtPedido.setVisible(false);
				}
			});
			lbPedido.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/pedido.png")));
			lbPedido.setBounds(696, 11, 133, 58);
		}
		return lbPedido;
	}
	private JScrollPane getScllPedido() {
		if (scllPedido == null) {
			scllPedido = new JScrollPane();
			scllPedido.setVisible(false);
			scllPedido.setBounds(610, 71, 212, 116);
			scllPedido.setViewportView(getTxtPedido());
		}
		return scllPedido;
	}
	private JTextArea getTxtPedido() {
		if (txtPedido == null) {
			txtPedido = new JTextArea();
			txtPedido.setBackground(Color.WHITE);
			txtPedido.setVisible(false);
			txtPedido.setEditable(false);
		}
		return txtPedido;
	}
	private JLabel getLbImgProducto() {
		if (lbImgProducto == null) {
			lbImgProducto = new JLabel("");
			lbImgProducto.setBackground(Color.WHITE);
			lbImgProducto.setBounds(237, 258, 186, 140);
		}
		return lbImgProducto;
	}
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnPedido());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnPedido() {
		if (mnPedido == null) {
			mnPedido = new JMenu("Pedido");
			mnPedido.setMnemonic('P');
			mnPedido.add(getMntmNuevo());
			mnPedido.add(getSeparator());
			mnPedido.add(getMntmSalir());
		}
		return mnPedido;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('Y');
			mnAyuda.add(getMntmContenidos());
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMntmNuevo() {
		if (mntmNuevo == null) {
			mntmNuevo = new JMenuItem("Nuevo");
			mntmNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar();
				}
			});
			mntmNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));
			mntmNuevo.setMnemonic('N');
		}
		return mntmNuevo;
	}
	private JMenuItem getMntmContenidos() {
		if (mntmContenidos == null) {
			mntmContenidos = new JMenuItem("Contenidos");
			mntmContenidos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Ayuda no disponible", "Contenidos", 2);
				}

				
			});
			mntmContenidos.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
			mntmContenidos.setMnemonic('C');
		}
		return mntmContenidos;
	}
	
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_DOWN_MASK));
			mntmSalir.setMnemonic('S');
		}
		return mntmSalir;
	}
	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca de...");
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Aplicacion para TPV de comida rapida...", "Acerca de...", 2);
				}
			});
			mntmAcercaDe.setMnemonic('A');
		}
		return mntmAcercaDe;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBounds(10, 11, 146, 387);
			panel.setLayout(new GridLayout(4, 1, 0, 0));
			panel.add(getBtHamburger());
			panel.add(getBtBebidas());
			panel.add(getBtComplementos());
			panel.add(getBtPostres());
		}
		return panel;
	}
	private JButton getBtPostres() {
		if (btPostres == null) {
			btPostres = new JButton("Postres");
			btPostres.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cbArticulos.setModel(new DefaultComboBoxModel<Articulo>(tipoArticulo("Postre")));
					actualizarCb();
				}
			});
			btPostres.setBackground(Color.WHITE);
			btPostres.setVerticalAlignment(SwingConstants.TOP);
			btPostres.setHorizontalTextPosition(SwingConstants.CENTER);
			btPostres.setVerticalTextPosition(SwingConstants.BOTTOM);
			btPostres.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Postre.png")));
		}
		return btPostres;
	}
	private JButton getBtHamburger() {
		if (btHamburger == null) {
			btHamburger = new JButton("Hamburgesas");
			btHamburger.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cbArticulos.setModel(new DefaultComboBoxModel<Articulo>(tipoArticulo("Hamburguesa")));
					actualizarCb();
				}
			});
			btHamburger.setBackground(Color.WHITE);
			btHamburger.setVerticalAlignment(SwingConstants.TOP);
			btHamburger.setVerticalTextPosition(SwingConstants.BOTTOM);
			btHamburger.setHorizontalTextPosition(SwingConstants.CENTER);
			btHamburger.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Hamburguesa.png")));
		}
		return btHamburger;
	}
	
	
	private JButton getBtBebidas() {
		if (btBebidas == null) {
			btBebidas = new JButton("Bebidas");
			btBebidas.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cbArticulos.setModel(new DefaultComboBoxModel<Articulo>(tipoArticulo("Bebida")));
					actualizarCb();
				}
			});
			btBebidas.setBackground(Color.WHITE);
			btBebidas.setVerticalAlignment(SwingConstants.TOP);
			btBebidas.setVerticalTextPosition(SwingConstants.BOTTOM);
			btBebidas.setHorizontalTextPosition(SwingConstants.CENTER);
			btBebidas.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Bebida.png")));
		}
		return btBebidas;
	}
	private JButton getBtComplementos() {
		if (btComplementos == null) {
			btComplementos = new JButton("Complementos");
			btComplementos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cbArticulos.setModel(new DefaultComboBoxModel<Articulo>(tipoArticulo("Complemento")));
					actualizarCb();
				}
			});
			btComplementos.setBackground(Color.WHITE);
			btComplementos.setVerticalAlignment(SwingConstants.TOP);
			btComplementos.setHorizontalTextPosition(SwingConstants.CENTER);
			btComplementos.setVerticalTextPosition(SwingConstants.BOTTOM);
			btComplementos.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/Complemento.png")));
		}
		return btComplementos;
	}
	
	private Articulo[] tipoArticulo(String tipo) {
		List<Articulo> ret = new ArrayList<Articulo>();
		
		if(tipo=="Hamburguesa") {
			for(Articulo a: carta.getArticulos())
				if(a.getTipo().equals("Hamburguesa"))
					ret.add(a);
		}else if(tipo=="Bebida") {
			for(Articulo a: carta.getArticulos())
				if(a.getTipo().equals("Bebida")) 
					ret.add(a);
		}else if(tipo=="Complemento") {
			for(Articulo a: carta.getArticulos())
				if(a.getTipo().equals("Complemento")) 
					ret.add(a);
		}else if(tipo=="Postre") {
			for(Articulo a: carta.getArticulos())
				if(a.getTipo().equals("Postre")) 
					ret.add(a);
		}
		
		Articulo[] articulos = ret.toArray(new Articulo[ret.size()]);
		return articulos;
	}
}
