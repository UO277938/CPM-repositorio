package gui;

import javax.swing.*;

import javax.swing.border.EmptyBorder;
import java.awt.Color;

import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class VentanaRegistro extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private VentanaPrincipal vPrincipal;
	private JPanel pnPrincipal;
	private JButton btCancelar;
	private JButton btnSiguiente;
	private JPanel pnPedido;
	private JPanel pnDatos;
	private JTextField txtNomApell;
	private JComboBox<String> cbA�oNacimiento;
	private JRadioButton rbLocal;
	private JRadioButton rbLlevar;
	private JLabel lblA�oNacimiento;
	private JLabel lblNombreYApellidos;
	private JLabel lbPassword;
	private JLabel lbRepeatPass;
	private JPasswordField psPass;
	private JPasswordField psRepeatPass;
	
	private final ButtonGroup bgPedido = new ButtonGroup();


	/**
	 * Create the frame.
	 */
	public VentanaRegistro(VentanaPrincipal vPrincipal) {
		this.vPrincipal = vPrincipal;
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaRegistro.class.getResource("/img/logo.png")));
		setTitle("McDonald's: Datos del cliente");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 300);
		pnPrincipal = new JPanel();
		pnPrincipal.setBackground(Color.WHITE);
		pnPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(pnPrincipal);
		pnPrincipal.setLayout(null);
		pnPrincipal.add(getBtCancelar());
		pnPrincipal.add(getBtnSiguiente());
		pnPrincipal.add(getPnPedido());
		pnPrincipal.add(getPnDatos());
	}
	
	public VentanaPrincipal getVp() {
		return vPrincipal;
	}
	
	private JButton getBtCancelar() {
		if (btCancelar == null) {
			btCancelar = new JButton("Cancelar");
			btCancelar.setMnemonic('C');
			btCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btCancelar.setForeground(Color.WHITE);
			btCancelar.setBackground(Color.RED);
			btCancelar.setBounds(485, 227, 89, 23);
		}
		return btCancelar;
	}
	private JButton getBtnSiguiente() {
		if (btnSiguiente == null) {
			btnSiguiente = new JButton("Siguiente");
			btnSiguiente.setMnemonic('S');
			btnSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					validarFormulario();
				}
			});
			btnSiguiente.setBackground(Color.GREEN);
			btnSiguiente.setForeground(Color.WHITE);
			btnSiguiente.setBounds(386, 227, 89, 23);
		}
		return btnSiguiente;
	}
	private JPanel getPnPedido() {
		if (pnPedido == null) {
			pnPedido = new JPanel();
			pnPedido.setBackground(Color.WHITE);
			pnPedido.setBorder(new TitledBorder(null, "Pedido", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			pnPedido.setBounds(28, 201, 275, 49);
			pnPedido.setLayout(null);
			pnPedido.add(getRbLocal());
			pnPedido.add(getRbLlevar());
		}
		return pnPedido;
	}
	private JPanel getPnDatos() {
		if (pnDatos == null) {
			pnDatos = new JPanel();
			pnDatos.setBackground(Color.WHITE);
			pnDatos.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Datos del Cliente", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			pnDatos.setBounds(28, 11, 528, 190);
			pnDatos.setLayout(null);
			pnDatos.add(getLblNombreYApellidos());
			pnDatos.add(getTxtNomApell());
			pnDatos.add(getLblA�oNacimiento());
			pnDatos.add(getCbA�oNacimiento());
			pnDatos.add(getLbPassword());
			pnDatos.add(getLbRepeatPass());
			pnDatos.add(getPsPass());
			pnDatos.add(getPsRepeatPass());
		}
		return pnDatos;
	}
	private JTextField getTxtNomApell() {
		if (txtNomApell == null) {
			txtNomApell = new JTextField();
			txtNomApell.setBounds(151, 21, 326, 20);
			txtNomApell.setColumns(40);
			txtNomApell.setBackground(Color.WHITE);
		}
		return txtNomApell;
	}
	private JComboBox<String> getCbA�oNacimiento() {
		if (cbA�oNacimiento == null) {
			String[] a�os =  new String[90];
			for(int i=0;i<90;i++)
				a�os[i] = " " + ((90-i)+1920);
			cbA�oNacimiento = new JComboBox<String>();
			cbA�oNacimiento.setBounds(151, 69, 101, 20);
			cbA�oNacimiento.setMaximumRowCount(100);
			cbA�oNacimiento.setEditable(true);
			cbA�oNacimiento.setModel(new DefaultComboBoxModel<String>(a�os));
		}
		return cbA�oNacimiento;
	}
	private JRadioButton getRbLocal() {
		if (rbLocal == null) {
			rbLocal = new JRadioButton("Local");
			rbLocal.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					vPrincipal.getPedido().setTomar(true);
				}
			});
			rbLocal.setMnemonic('L');
			bgPedido.add(rbLocal);
			rbLocal.setBounds(51, 21, 78, 23);
			rbLocal.setBackground(Color.WHITE);
			rbLocal.setSelected(true);
		}
		return rbLocal;
	}
	private JRadioButton getRbLlevar() {
		if (rbLlevar == null) {
			rbLlevar = new JRadioButton("Llevar");
			rbLlevar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					vPrincipal.getPedido().setTomar(false);
				}
			});
			rbLlevar.setMnemonic('v');
			bgPedido.add(rbLlevar);
			rbLlevar.setBounds(144, 21, 78, 23);
			rbLlevar.setBackground(Color.WHITE);
		}
		return rbLlevar;
	}
	private JLabel getLblA�oNacimiento() {
		if (lblA�oNacimiento == null) {
			lblA�oNacimiento = new JLabel("A\u00F1o de nacimiento:");
			lblA�oNacimiento.setLabelFor(getCbA�oNacimiento());
			lblA�oNacimiento.setDisplayedMnemonic('A');
			lblA�oNacimiento.setBounds(10, 72, 92, 14);
		}
		return lblA�oNacimiento;
	}
	private JLabel getLblNombreYApellidos() {
		if (lblNombreYApellidos == null) {
			lblNombreYApellidos = new JLabel("Nombre y Apellidos:");
			lblNombreYApellidos.setLabelFor(getTxtNomApell());
			lblNombreYApellidos.setDisplayedMnemonic('N');
			lblNombreYApellidos.setBounds(10, 27, 131, 14);
		}
		return lblNombreYApellidos;
	}
	private JLabel getLbPassword() {
		if (lbPassword == null) {
			lbPassword = new JLabel("Password:");
			lbPassword.setLabelFor(getPsPass());
			lbPassword.setDisplayedMnemonic('P');
			lbPassword.setBounds(10, 117, 50, 14);
		}
		return lbPassword;
	}
	private JLabel getLbRepeatPass() {
		if (lbRepeatPass == null) {
			lbRepeatPass = new JLabel("Reintroduzca password:");
			lbRepeatPass.setLabelFor(getPsRepeatPass());
			lbRepeatPass.setDisplayedMnemonic('R');
			lbRepeatPass.setBounds(10, 153, 116, 14);
		}
		return lbRepeatPass;
	}
	private JPasswordField getPsPass() {
		if (psPass == null) {
			psPass = new JPasswordField();
			psPass.setBackground(Color.WHITE);
			psPass.setBounds(151, 111, 190, 20);
		}
		return psPass;
	}
	private JPasswordField getPsRepeatPass() {
		if (psRepeatPass == null) {
			psRepeatPass = new JPasswordField();
			psRepeatPass.setBackground(Color.WHITE);
			psRepeatPass.setBounds(151, 150, 190, 20);
		}
		return psRepeatPass;
	}
	
	private void validarFormulario() {
		if(getTxtNomApell().getText().isBlank() || String.valueOf(getPsPass().getPassword()).isBlank() || String.valueOf(getPsRepeatPass().getPassword()).isBlank())
			JOptionPane.showMessageDialog(null, "Falta rellenar algun campo.");
		else if(!String.valueOf(getPsPass().getPassword()).equals(String.valueOf(getPsRepeatPass().getPassword())))
			JOptionPane.showMessageDialog(null, "Contrase�as no son iguales.");
		else
			mostrarVentanaConfirmacion();
	}
	
	
	private void mostrarVentanaConfirmacion() {
		VentanaConfirmacion vConfirmacion = new VentanaConfirmacion(this);
		vConfirmacion.setLocationRelativeTo(this);
		vConfirmacion.setModal(true);
		vConfirmacion.setVisible(true);
	}
}
