package logica;

import java.util.*;

public class Carta {
	
	private static final String FICHERO_ARTICULOS = "src/files/articulos.dat";
	private static List<Articulo> listaArticulos = null;
	
	/**
	 * Clase Carta que utiiliza el FileUtil para crar la carta.
	 */
	public Carta(){
		listaArticulos = new ArrayList<Articulo>();
		cargarArticulos();
	}

	/**
	 * carga los articulos del archivo articulos.dat
	 */
	private void cargarArticulos(){
		FileUtil.loadFile (FICHERO_ARTICULOS, listaArticulos);
	}

	/**
	 * Devuelve la lista de articulos de la carta
	 * @return
	 */
	public Articulo[] getArticulos(){
		Articulo[] articulos = listaArticulos.toArray(new Articulo[listaArticulos.size()]);
		return articulos;	
	}	
}
