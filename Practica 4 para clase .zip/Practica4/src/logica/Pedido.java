package logica;

import java.util.*;

public class Pedido {
	
	private List<Articulo> listaPedido;
	private String codigo;
	private boolean descuentoAplicado;
	private boolean tomar;
	
	
	public Pedido(){
		listaPedido = new ArrayList<Articulo>();
		tomar = true;
		inicializar();
	}

	public void inicializar(){
		listaPedido.clear();
		generarCodigo();
		setDescuentoAplicado(false);
	}
	
	private void setDescuentoAplicado(boolean cond) {
		descuentoAplicado = cond;
	}
	
	public boolean getDescuentoAplicado() {
		return descuentoAplicado;
	}
	
	public boolean isTomar() {
		return tomar;
	}

	public void setTomar(boolean tomar) {
		this.tomar = tomar;
	}

	/**
	 * a�ade articulo al pedido
	 * @param articuloDelCatalogo
	 * @param unidades
	 */
	public void add(Articulo articuloDelCatalogo, int unidades){
		Articulo articuloEnPedido = null;
	
		for (Articulo a : listaPedido){
			if (a.getCodigo().equals(articuloDelCatalogo.getCodigo()))
			{
				articuloEnPedido = a;
				articuloEnPedido.setUnidades(articuloEnPedido.getUnidades() + unidades);
				break;
			}
		}
		
		if (articuloEnPedido == null){
			Articulo articuloAPedido = new Articulo(articuloDelCatalogo);
			articuloAPedido.setUnidades(unidades);
			listaPedido.add(articuloAPedido);
		}
		
	}
	
	
	public void remove(Articulo articuloDelCatalogo, int unidades) {
		Articulo articuloEnPedido = null;
		for(Articulo a : listaPedido) {
			if(a.getCodigo().equals(articuloDelCatalogo.getCodigo())) 
				articuloEnPedido = a;
		}
		if(articuloEnPedido != null) {
			int totalUnidades = articuloEnPedido.getUnidades() - unidades;
			if(totalUnidades <= 0)
				listaPedido.remove(articuloEnPedido);
			else
				articuloEnPedido.setUnidades(totalUnidades);
		}
		
	}
	
	
	public Articulo getListaPedido(Articulo articulo){
		for(Articulo a: listaPedido)
			if (a.getCodigo().equals(articulo.getCodigo())) {
				return a;
			}
		return null;
	}
	
	/**
	 * devuelve el precio de toda la compra
	 * @return
	 */
	public float getTotal() {
		float precio = 0;
		for (Articulo a : listaPedido){
			precio += a.getPrecio()* a.getUnidades();
		}
		if(precio>=50) {
			float descuento = (float) (precio*0.1); 
			setDescuentoAplicado(true);
			return precio - descuento;
		}
		return precio;
	}
	
	/**
	 * guarda el pedido en un archivo 
	 */
	public void grabarPedido(){
		FileUtil.saveToFile(codigo, listaPedido, tomar);
	  }

	public String getCodigo() {
		return codigo;
	}

	private void generarCodigo() {
		codigo = "";
		String base = "0123456789abcdefghijklmnopqrstuvwxyz";
		int longitudCodigo = 8;
		for(int i=0; i<longitudCodigo;i++){ 
			int numero = (int)(Math.random()*(base.length())); 
			codigo += base.charAt(numero);
		}
	}

	public boolean isVacio() {
		return listaPedido.size()==0;
	}
	
	/**
	 * Metodo para mostrar el pedido en la ventana principal
	 */
	public String toString() {
		String str = "";
		for (Articulo a : listaPedido){
			str += a.getDenominacion() + " - " + a.getUnidades() + "\n";
		}str+="Total: " + getTotal() + " �";
		return str;
	}
	
}
