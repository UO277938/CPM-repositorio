package gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Articulo;
import logica.Carta;
import logica.Pedido;

import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class VentanaPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel contentPane;
	private JLabel lbLogo;
	private JLabel lbMcDonalds;
	private JTextField txtPrecioPedido;
	private JSpinner spUnidades;
	private JLabel lbPrecioPedido;
	private JButton btnSiguiente;
	private JButton btCancelar;
	private JButton btAdd;
	private JLabel lbArticulos;
	private JComboBox<Articulo> cbArticulos;
	private JLabel lbUnidades;
	private Carta carta;
	private Pedido pedido;
	private JTextPane txtUnidades;
	private JButton btEliminar;
	private JLabel lbPedido;
	private JScrollPane scllPedido;
	private JTextArea txtPedido;

	
//	public static void main(String[] args) {
//		Carta carta = new Carta();
//		Pedido pedido = new Pedido();
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					VentanaPrincipal frame = new VentanaPrincipal(carta,pedido);
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	
	
	
	/**
	 * Create the frame.
	 */
	public VentanaPrincipal(Carta carta, Pedido pedido) {
		this.carta = carta;
		this.pedido = pedido;
		setResizable(false);
		setTitle("McDonald's Espa\u00F1a");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 693, 403);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLbLogo());
		contentPane.add(getLbMcDonalds());
		contentPane.add(getTxtPrecioPedido());
		contentPane.add(getSpUnidades());
		contentPane.add(getLbPrecioPedido());
		contentPane.add(getBtnSiguiente());
		contentPane.add(getBtCancelar());
		contentPane.add(getBtAdd());
		contentPane.add(getLbArticulos());
		contentPane.add(getCbArticulos());
		contentPane.add(getLbUnidades());
		contentPane.add(getTxtUnidades());
		contentPane.add(getBtEliminar());
		contentPane.add(getLbPedido());
		contentPane.add(getScllPedido());
	}
	
	//reinicia la aplicacion para que lo use mas de un usuario
	public void inicializar() {
		pedido.inicializar(); //equisde
		getCbArticulos().setSelectedIndex(0); //primer elemento
		getSpUnidades().setValue(1); // 1 unidad
		getTxtPrecioPedido().setText(""); //vacia 
		getLbUnidades().setText(""); //vacia
		getLbPrecioPedido().setText("Precio Pedido: "); //vacia
		getBtnSiguiente().setEnabled(false); //desavilita el boton
		getBtCancelar().setEnabled(false);
	}
	
	
	public Pedido getPedido() {
		return pedido;
	}
	
	
	private JLabel getLbLogo() {
		if (lbLogo == null) {
			lbLogo = new JLabel("New label");
			lbLogo.setBounds(27, 11, 150, 147);
			lbLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.png")));
		}
		return lbLogo;
	}
	private JLabel getLbMcDonalds() {
		if (lbMcDonalds == null) {
			lbMcDonalds = new JLabel("McDonald's");
			lbMcDonalds.setBounds(187, 60, 231, 69);
			lbMcDonalds.setFont(new Font("Arial Black", Font.PLAIN, 34));
		}
		return lbMcDonalds;
	}
	private JTextField getTxtPrecioPedido() {
		if (txtPrecioPedido == null) {
			txtPrecioPedido = new JTextField();
			txtPrecioPedido.setFont(new Font("Tahoma", Font.PLAIN, 13));
			txtPrecioPedido.setBounds(317, 297, 86, 30);
			txtPrecioPedido.setEditable(false);
			txtPrecioPedido.setColumns(10);
		}
		return txtPrecioPedido;
	}
	@SuppressWarnings("deprecation")
	private JSpinner getSpUnidades() {
		if (spUnidades == null) {
			spUnidades = new JSpinner();
			spUnidades.setFont(new Font("Tahoma", Font.PLAIN, 13));
			spUnidades.setBounds(317, 231, 72, 30);
			spUnidades.setBackground(Color.WHITE);
			spUnidades.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		}
		return spUnidades;
	}
	private JLabel getLbPrecioPedido() {
		if (lbPrecioPedido == null) {
			lbPrecioPedido = new JLabel("Precio Pedido:");
			lbPrecioPedido.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lbPrecioPedido.setBounds(317, 272, 170, 14);
		}
		return lbPrecioPedido;
	}
	private JButton getBtnSiguiente() {
		if (btnSiguiente == null) {
			btnSiguiente = new JButton("Siguiente");
			btnSiguiente.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btnSiguiente.setMnemonic('S');
			btnSiguiente.setBounds(473, 320, 89, 30);
			btnSiguiente.setEnabled(false);
			btnSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarVentanaRegistro();
				}
			});
			btnSiguiente.setForeground(Color.WHITE);
			btnSiguiente.setBackground(Color.GREEN);
		}
		return btnSiguiente;
	}
	private JButton getBtCancelar() {
		if (btCancelar == null) {
			btCancelar = new JButton("Cancelar");
			btCancelar.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btCancelar.setMnemonic('C');
			btCancelar.setEnabled(false);
			btCancelar.setBounds(572, 320, 89, 30);
			btCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(!pedido.isVacio()) 
						if(confirmarCancelacion())
								inicializar();
				}

				
				
			});
			btCancelar.setForeground(Color.WHITE);
			btCancelar.setBackground(Color.RED);
		}
		return btCancelar;
	}
	
	private boolean confirmarCancelacion() {
		boolean yes = false;
		int resp = JOptionPane.showConfirmDialog(btCancelar, this, "�Est� seguro de cancelar el pedido?", 0);
		if(resp == JOptionPane.YES_OPTION)
			yes = true;
		return yes;
	}
	
	
	private JButton getBtAdd() {
		if (btAdd == null) {
			btAdd = new JButton("A\u00F1adir");
			btAdd.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btAdd.setBounds(426, 230, 86, 30);
			btAdd.setMnemonic('A');
			btAdd.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					a�adirAPedido();
					btEliminar.setEnabled(true);
				}
			});
			btAdd.setForeground(Color.WHITE);
			btAdd.setBackground(Color.GREEN);
		}
		return btAdd;
	}
	
	
	private JButton getBtEliminar() {
		if (btEliminar == null) {
			btEliminar = new JButton("Eliminar");
			btEliminar.setEnabled(false);
			btEliminar.setFont(new Font("Tahoma", Font.PLAIN, 13));
			btEliminar.setMnemonic('E');
			btEliminar.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {
					eliminarDePedido();
					if(pedido.getListaPedido( (Articulo) cbArticulos.getSelectedItem()) == null)
						btEliminar.setEnabled(false);
				}

				
			});
			btEliminar.setForeground(Color.WHITE);
			btEliminar.setBackground(Color.GREEN);
			btEliminar.setBounds(522, 230, 86, 31);
		}
		return btEliminar;
	}
	
	private void eliminarDePedido() {
		Articulo articuloSeleccionado = (Articulo) getCbArticulos().getSelectedItem();
		int unidadesEliminar = (int) getSpUnidades().getValue();
		pedido.remove(articuloSeleccionado, unidadesEliminar);
		String precio = String.format("%.2f", pedido.getTotal());
		getTxtPrecioPedido().setText(precio + (" \u20AC"));
		if(pedido.getTotal() == 0) {
			btnSiguiente.setEnabled(false);
			txtPrecioPedido.setText("");
		}
		//descuentos
	}
	
	
	private JLabel getLbArticulos() {
		if (lbArticulos == null) {
			lbArticulos = new JLabel("Articulos:");
			lbArticulos.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lbArticulos.setBounds(27, 205, 86, 14);
			lbArticulos.setLabelFor(getCbArticulos());
			lbArticulos.setDisplayedMnemonic('R');
		}
		return lbArticulos;
	}
	
	private JComboBox<Articulo> getCbArticulos() {
		if (cbArticulos == null) {
			cbArticulos = new JComboBox<Articulo>();
			cbArticulos.setFont(new Font("Tahoma", Font.PLAIN, 13));
			cbArticulos.setBounds(27, 230, 269, 30);
			cbArticulos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					getSpUnidades().setValue(1);
					if(pedido.getListaPedido( (Articulo) cbArticulos.getSelectedItem()) != null)
						btEliminar.setEnabled(true);
					else btEliminar.setEnabled(false);
				}
			});
			cbArticulos.setModel(new DefaultComboBoxModel<Articulo>(carta.getArticulos()));
		}
		return cbArticulos;
	}
	private JLabel getLbUnidades() {
		if (lbUnidades == null) {
			lbUnidades = new JLabel("Unidades:");
			lbUnidades.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lbUnidades.setBounds(317, 206, 72, 14);
			lbUnidades.setLabelFor(getSpUnidades());
			lbUnidades.setDisplayedMnemonic('U');
		}
		return lbUnidades;
	}
	
	
	private void mostrarVentanaRegistro() {
		VentanaRegistro vRegistro = new VentanaRegistro(this);
		vRegistro.setLocationRelativeTo(this);
		vRegistro.setModal(true);
		vRegistro.setVisible(true);
	}
	
	private void a�adirAPedido() {
		Articulo articuloSeleccionado = (Articulo) getCbArticulos().getSelectedItem();
		int unidadesSolicitadas = (int) getSpUnidades().getValue();
		pedido.add(articuloSeleccionado, unidadesSolicitadas);
		String precio = String.format("%.2f", pedido.getTotal());
		getTxtPrecioPedido().setText(precio + (" \u20AC"));
		if(pedido.getDescuentoAplicado()) {
			lbPrecioPedido.setText("Precio CON el descuento: ");		
		}
		if(!getBtnSiguiente().isEnabled())
			getBtnSiguiente().setEnabled(true);
		if(!getBtCancelar().isEnabled())
			getBtCancelar().setEnabled(true);
	}
	
	
	
	
	
	
	private JTextPane getTxtUnidades() {
		if (txtUnidades == null) {
			int unidades = 0;
			txtUnidades = new JTextPane();
			txtUnidades.setBounds(27, 266, 170, 20);
			txtUnidades.setForeground(Color.RED);
			txtUnidades.setBackground(Color.WHITE);
			txtUnidades.setEnabled(true);
			if(cbArticulos.getSelectedItem()!=null) {
				Articulo arti = pedido.getListaPedido((Articulo)cbArticulos.getSelectedItem());
				if(arti!=null) 
					unidades = arti.getUnidades();
			}
			txtUnidades.setText("Tienes " + unidades + " de este producto.");
		}
		return txtUnidades;
	}
	private JLabel getLbPedido() {
		if (lbPedido == null) {
			lbPedido = new JLabel("");
			lbPedido.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					scllPedido.setVisible(true);
					txtPedido.setVisible(true);
					txtPedido.setText(pedido.toString());
				}
				@Override
				public void mouseReleased(MouseEvent e) {
					scllPedido.setVisible(false);
					txtPedido.setVisible(false);
				}
			});
			lbPedido.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/pedido.png")));
			lbPedido.setBounds(528, 11, 133, 58);
		}
		return lbPedido;
	}
	private JScrollPane getScllPedido() {
		if (scllPedido == null) {
			scllPedido = new JScrollPane();
			scllPedido.setVisible(false);
			scllPedido.setBounds(449, 71, 212, 116);
			scllPedido.setViewportView(getTxtPedido());
		}
		return scllPedido;
	}
	private JTextArea getTxtPedido() {
		if (txtPedido == null) {
			txtPedido = new JTextArea();
			txtPedido.setBackground(Color.WHITE);
			txtPedido.setVisible(false);
			txtPedido.setEditable(false);
		}
		return txtPedido;
	}
}
