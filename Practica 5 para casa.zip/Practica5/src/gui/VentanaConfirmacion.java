package gui;

import javax.swing.JDialog;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;

public class VentanaConfirmacion extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel lbIcono;
	private JLabel lbCodigo;
	private JTextField txtCodigo;
	private JButton btFinalizar;
	
	private VentanaRegistro vRegistro;
	private JTextPane txtPrecioFinal;


	/**
	 * Create the dialog.
	 */
	public VentanaConfirmacion(VentanaRegistro vRegistro) {
		this.vRegistro = vRegistro;
		getContentPane().setBackground(Color.WHITE);
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaConfirmacion.class.getResource("/img/logo.png")));
		setTitle("McDonal's: Confirmaci\u00F3n del pedido");
		setBounds(100, 100, 614, 411);
		getContentPane().setLayout(null);
		getContentPane().add(getLbIcono());
		getContentPane().add(getLbCodigo());
		getContentPane().add(getTxtCodigo());
		getContentPane().add(getBtFinalizar());
		getContentPane().add(getTxtPrecioFinal());

	}
	
	public VentanaRegistro getVr() {
		return vRegistro;
	}
	

	private JLabel getLbIcono() {
		if (lbIcono == null) {
			lbIcono = new JLabel("Pulse Finalizar para confirmar su pedido");
			lbIcono.setFont(new Font("Arial Black", Font.PLAIN, 20));
			lbIcono.setIcon(new ImageIcon(VentanaConfirmacion.class.getResource("/img/ok.png")));
			lbIcono.setBounds(35, 105, 520, 55);
		}
		return lbIcono;
	}
	private JLabel getLbCodigo() {
		if (lbCodigo == null) {
			lbCodigo = new JLabel("El c\u00F3digo de recogida es:");
			lbCodigo.setFont(new Font("Tahoma", Font.PLAIN, 17));
			lbCodigo.setBounds(114, 222, 209, 21);
		}
		return lbCodigo;
	}
	private JTextField getTxtCodigo() {
		if (txtCodigo == null) {
			txtCodigo = new JTextField();
			txtCodigo.setFont(new Font("Tahoma", Font.PLAIN, 16));
			txtCodigo.setEditable(false);
			txtCodigo.setBounds(319, 222, 137, 30);
			txtCodigo.setColumns(10);
			txtCodigo.setHorizontalAlignment((int) CENTER_ALIGNMENT);
			txtCodigo.setText(vRegistro.getVp().getPedido().getCodigo());
		}
		return txtCodigo;
	}
	private JButton getBtFinalizar() {
		if (btFinalizar == null) {
			btFinalizar = new JButton("Finalizar");
			btFinalizar.setMnemonic('F');
			btFinalizar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					finalizar();
				}
			});
			btFinalizar.setForeground(Color.WHITE);
			btFinalizar.setBackground(Color.GREEN);
			btFinalizar.setBounds(469, 322, 89, 23);
		}
		return btFinalizar;
	}
	private JTextPane getTxtPrecioFinal() {
		if (txtPrecioFinal == null) {
			
			txtPrecioFinal = new JTextPane();
			txtPrecioFinal.setFont(new Font("Tahoma", Font.PLAIN, 16));
			txtPrecioFinal.setBackground(Color.WHITE);
			txtPrecioFinal.setBounds(114, 278, 244, 30);
			float precioFinal = vRegistro.getVp().getPedido().getTotal();
			DecimalFormat format = new DecimalFormat("#.00");
			txtPrecioFinal.setText("El precio final es: " + format.format(precioFinal)+ " \u20AC");
		}
		return txtPrecioFinal;
	}
	
	private void finalizar() {
		vRegistro.getVp().getPedido().grabarPedido();
		vRegistro.getVp().inicializar();
		vRegistro.dispose();
		this.dispose();
		
	}
}
