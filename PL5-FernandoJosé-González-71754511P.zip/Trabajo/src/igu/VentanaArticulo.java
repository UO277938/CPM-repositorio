package igu;

import javax.swing.JFrame;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JSpinner;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JPanel;
import javax.swing.SpinnerNumberModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import logica.Regalo;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import java.awt.Toolkit;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.awt.event.InputEvent;

public class VentanaArticulo extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel pnBotones;
	private JPanel pnPrecio;
	private JPanel pnCantidad;
	private JButton btCanjear;
	private JButton btSalir;
	private JLabel lbPrecio;
	private JTextField txtPrecio;
	private JLabel lbCantidad;
	private JSpinner spinnerCantidad;
	private JPanel pnDescripcion;
	private JLabel lbDenominaciion;
	private JScrollPane scrollPane;
	private JTextArea txtDescripcion;
	private JPanel panel_3;
	private JLabel lbTusPuntos;
	private JTextField textField;
	private JButton btFoto;
	
	private Regalo regalo;
	private int tusPuntos;
	private VentanaPremios vPremios;
	private JMenuBar menuBar;
	private JMenu mnPartida;
	private JMenuItem mntmSalir;
	private JMenu mnAyuda;
	private JMenuItem mntmAyuda;
	private JSeparator separator_1;
	private JMenuItem mntmAcercaDe;
	
	
	public VentanaArticulo(Regalo regalo, int puntos, VentanaPremios vPremios) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaArticulo.class.getResource("/img/regalo.jpg")));
		setTitle("Pantalla del Premio");
		this.regalo= regalo;
		this.tusPuntos = puntos;
		this.vPremios = vPremios;
		getTextField().setText("" + tusPuntos);
		cargaAyuda();
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				asociaImagenBotones();
			}
		});
		
		getContentPane().setBackground(new Color(204, 255, 102));
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(getPanel(), BorderLayout.CENTER);
		getContentPane().add(getPanel_1(), BorderLayout.EAST);
		getContentPane().add(getMenuBar_1(), BorderLayout.NORTH);
		setBounds(100, 100, 450, 500);
		
		getSpinnerCantidad().grabFocus();
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(new Color(204, 255, 102));
			panel.setLayout(new GridLayout(0, 1, 0, 0));
			panel.add(getBtFoto());
			panel.add(getPnDescripcion());
		}
		return panel;
	}
	private JPanel getPanel_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBackground(new Color(204, 255, 102));
			panel_1.setLayout(new BorderLayout(0, 0));
			panel_1.add(getPanel_2_1(), BorderLayout.CENTER);
			panel_1.add(getPnBotones(), BorderLayout.SOUTH);
		}
		return panel_1;
	}
	private JPanel getPanel_2_1() {
		if (panel_2 == null) {
			panel_2 = new JPanel();
			panel_2.setBackground(new Color(204, 255, 102));
			panel_2.setLayout(new GridLayout(3, 1, 0, 2));
			panel_2.add(getPanel_3());
			panel_2.add(getPnPrecio());
			panel_2.add(getPnCantidad());
		}
		return panel_2;
	}
	private JPanel getPnBotones() {
		if (pnBotones == null) {
			pnBotones = new JPanel();
			pnBotones.setBackground(new Color(204, 255, 102));
			pnBotones.setLayout(new GridLayout(2, 1, 4, 2));
			pnBotones.add(getBtCanjear());
			pnBotones.add(getBtSalir());
		}
		return pnBotones;
	}
	private JPanel getPnPrecio() {
		if (pnPrecio == null) {
			pnPrecio = new JPanel();
			pnPrecio.setBackground(new Color(204, 255, 102));
			pnPrecio.setLayout(new BorderLayout(0, 0));
			pnPrecio.add(getLbPrecio(), BorderLayout.NORTH);
			pnPrecio.add(getTxtPrecio(), BorderLayout.CENTER);
		}
		return pnPrecio;
	}
	private JPanel getPnCantidad() {
		if (pnCantidad == null) {
			pnCantidad = new JPanel();
			pnCantidad.setBackground(new Color(204, 255, 102));
			pnCantidad.setLayout(new BorderLayout(0, 0));
			pnCantidad.add(getLbCantidad(), BorderLayout.NORTH);
			pnCantidad.add(getSpinnerCantidad(), BorderLayout.CENTER);
		}
		return pnCantidad;
	}
	private JButton getBtCanjear() {
		if (btCanjear == null) {
			btCanjear = new JButton("Canjear");
			btCanjear.setMnemonic('C');
			btCanjear.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Integer a = regalo.getPrecio();
					float precio = a.floatValue();
					Integer b = (Integer) getSpinnerCantidad().getValue();
					float cantidad = b.floatValue();
					if(tusPuntos >= ( precio * cantidad) ) {
						a�adirAEntrega(regalo, b);
						dispose();
					}
				}
			});
			btCanjear.setBackground(new Color(153, 204, 204));
			btCanjear.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btCanjear;
	}
	
	/**
	 * Metodo que a�ade internamente al carrito el regalo y su cantidad
	 * @param regalo a canjear
	 * @param cantidad que se va a canjear
	 */
	private void a�adirAEntrega(Regalo regalo, int cantidad) {
		vPremios.getEntrega().add(regalo, cantidad);
		System.out.println(vPremios.getEntrega().toString());
		vPremios.actualizarVentanaPremios(regalo, cantidad);
	}
	
	private JButton getBtSalir() {
		if (btSalir == null) {
			btSalir = new JButton("Salir");
			btSalir.setMnemonic('S');
			btSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btSalir.setBackground(new Color(153, 204, 204));
			btSalir.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btSalir;
	}
	private JLabel getLbPrecio() {
		if (lbPrecio == null) {
			lbPrecio = new JLabel("Precio:");
			lbPrecio.setHorizontalAlignment(SwingConstants.CENTER);
			lbPrecio.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return lbPrecio;
	}
	private JTextField getTxtPrecio() {
		if (txtPrecio == null) {
			txtPrecio = new JTextField();
			txtPrecio.setBackground(new Color(204, 255, 255));
			txtPrecio.setHorizontalAlignment(SwingConstants.CENTER);
			txtPrecio.setEditable(false);
			txtPrecio.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txtPrecio.setColumns(10);
			txtPrecio.setText("" + regalo.getPrecio());
		}
		return txtPrecio;
	}
	private JLabel getLbCantidad() {
		if (lbCantidad == null) {
			lbCantidad = new JLabel("Cantidad");
			lbCantidad.setDisplayedMnemonic('T');
			lbCantidad.setLabelFor(getSpinnerCantidad());
			lbCantidad.setHorizontalAlignment(SwingConstants.CENTER);
			lbCantidad.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return lbCantidad;
	}
	@SuppressWarnings("removal")
	private JSpinner getSpinnerCantidad() {
		if (spinnerCantidad == null) {
			spinnerCantidad = new JSpinner();
			spinnerCantidad.setBackground(new Color(153, 204, 204));
			spinnerCantidad.setFont(new Font("Tahoma", Font.PLAIN, 16));
			spinnerCantidad.setModel(new SpinnerNumberModel(new Integer(1), new Integer(0), null, new Integer(1)));
		}
		return spinnerCantidad;
	}
	private JPanel getPnDescripcion() {
		if (pnDescripcion == null) {
			pnDescripcion = new JPanel();
			pnDescripcion.setBackground(new Color(204, 255, 102));
			pnDescripcion.setLayout(new BorderLayout(0, 0));
			pnDescripcion.add(getLbDenominaciion(), BorderLayout.NORTH);
			pnDescripcion.add(getScrollPane(), BorderLayout.CENTER);
		}
		return pnDescripcion;
	}
	private JLabel getLbDenominaciion() {
		if (lbDenominaciion == null) {
			lbDenominaciion = new JLabel(regalo.getDenominacion());
			lbDenominaciion.setHorizontalAlignment(SwingConstants.CENTER);
			lbDenominaciion.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return lbDenominaciion;
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getTxtDescripcion());
		}
		return scrollPane;
	}
	private JTextArea getTxtDescripcion() {
		if (txtDescripcion == null) {
			txtDescripcion = new JTextArea();
			txtDescripcion.setFont(new Font("Monospaced", Font.PLAIN, 16));
			txtDescripcion.setLineWrap(true);
			txtDescripcion.setColumns(20);
			txtDescripcion.setBackground(new Color(204, 255, 255));
			txtDescripcion.setEditable(false);
			txtDescripcion.setText(regalo.getDescripcion());
		}
		return txtDescripcion;
	}
	private JPanel getPanel_3() {
		if (panel_3 == null) {
			panel_3 = new JPanel();
			panel_3.setBackground(new Color(204, 255, 102));
			panel_3.setLayout(new BorderLayout(0, 0));
			panel_3.add(getLbTusPuntos(), BorderLayout.NORTH);
			panel_3.add(getTextField(), BorderLayout.CENTER);
		}
		return panel_3;
	}
	private JLabel getLbTusPuntos() {
		if (lbTusPuntos == null) {
			lbTusPuntos = new JLabel("Tus Puntos:");
			lbTusPuntos.setHorizontalAlignment(SwingConstants.CENTER);
			lbTusPuntos.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return lbTusPuntos;
	}
	private JTextField getTextField() {
		if (textField == null) {
			textField = new JTextField();
			textField.setBackground(new Color(204, 255, 255));
			textField.setHorizontalAlignment(SwingConstants.CENTER);
			textField.setEditable(false);
			textField.setFont(new Font("Tahoma", Font.PLAIN, 14));
			textField.setColumns(10);
		}
		return textField;
	}
	
	private JButton getBtFoto() {
		if (btFoto == null) {
			btFoto = new JButton("");
			btFoto.setBackground(new Color(153, 204, 51));
			btFoto.setSize(new Dimension(300, 300));
			setImagenAdaptada(btFoto, "/img/" + regalo.getCodigo()+ ".png");
		}
		return btFoto;
	}
	
	/**
	 * Metodo que adapta la imagen para un boton segun el tama�o de la ventana
	 * @param boton a adaptar la imagen
	 * @param rutaImagen imagen a adaptar
	 */
	private void setImagenAdaptada(JButton boton, String rutaImagen){
		 Image imgOriginal = new ImageIcon(getClass().getResource(rutaImagen)).getImage(); 
		 Image imgEscalada = imgOriginal.getScaledInstance(boton.getWidth(),boton.getHeight(), Image.SCALE_FAST);
		 ImageIcon icon = new ImageIcon(imgEscalada);
		 boton.setIcon(icon);
	}
	
	/**
	 * Metodo que asocia las imagenes adaptadas con los botones
	 */
	private void asociaImagenBotones() {
		setImagenAdaptada(btFoto, "/img/"+ regalo.getCodigo()+".png");
	}
	
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnPartida());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnPartida() {
		if (mnPartida == null) {
			mnPartida = new JMenu("Partida");
			mnPartida.setMnemonic('P');
			mnPartida.add(getMntmSalir());
		}
		return mnPartida;
	}
	@SuppressWarnings("deprecation")
	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(ABORT);
				}
			});
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_MASK));
			mntmSalir.setMnemonic('S');
		}
		return mntmSalir;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('A');
			mnAyuda.add(getMntmAyuda());
			mnAyuda.add(getSeparator_1());
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMntmAyuda() {
		if (mntmAyuda == null) {
			mntmAyuda = new JMenuItem("Ayuda");
			mntmAyuda.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
			mntmAyuda.setMnemonic('A');
		}
		return mntmAyuda;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca De...");
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Esta aplicacion ha sido realizada por\n Fernando Jos� Gonz�lez Sierra", "Acerca De...", 1, null);
				}
			});
		}
		return mntmAcercaDe;
	}
	
	/**
	 * Metodo que carga la ayuda de la aplicacion y se le asigna el boton F1 para abrirla
	 */
	private void cargaAyuda(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"articulo", hs); //activar F1
		   hb.enableHelpOnButton(getMntmAyuda(), "articulo", hs);
		   
		 }
}
