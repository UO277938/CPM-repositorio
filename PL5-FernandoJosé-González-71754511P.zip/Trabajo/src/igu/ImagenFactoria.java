package igu;

import javax.swing.ImageIcon;

import logica.Casilla;
import logica.Casilla_Especial;
import logica.Casilla_Multiplica;
import logica.Casilla_Puntos_1000;
import logica.Casilla_Puntos_250;
import logica.Casilla_Puntos_50;

public class ImagenFactoria {

	private static final String IMAGEN_0 = "/img/cero.JPG";
	private static final String IMAGEN_50 = "/img/50.PNG";
	private static final String IMAGEN_250 = "/img/250.PNG";
	private static final String IMAGEN_1000 = "/img/1000.PNG";
	private static final String IMAGEN_X2 = "/img/x2.PNG";
	private static final String IMAGEN_VACIO = "/img/nada.PNG";
	private static final String IMAGEN_REGALO = "/img/regalo.jpg";
	

	public static ImageIcon getImagen(Casilla casilla) {
		if (casilla instanceof Casilla_Puntos_50)
			return cargaImagen(IMAGEN_50);
		else if (casilla instanceof Casilla_Puntos_250)
			return cargaImagen(IMAGEN_250);
		else if (casilla instanceof Casilla_Puntos_1000)
			return cargaImagen(IMAGEN_1000);
		else if (casilla instanceof Casilla_Especial)
			return cargaImagen(IMAGEN_VACIO);
		else if (casilla instanceof Casilla_Multiplica)
			return cargaImagen(IMAGEN_X2);
		else
			return cargaImagen(IMAGEN_0);
	}

	public static ImageIcon getImagen()
	{
		return cargaImagen(IMAGEN_REGALO);
	}
	
	private static ImageIcon cargaImagen(String fichero) {
		return new ImageIcon(ImagenFactoria.class.getResource(fichero));
	}
}
