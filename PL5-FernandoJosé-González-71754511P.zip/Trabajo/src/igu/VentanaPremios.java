package igu;

import javax.swing.JFrame;
import java.awt.Color;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.Image;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;

import java.awt.BorderLayout;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Toolkit;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import logica.Carta;
import logica.Entrega;
import logica.Regalo;

import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.awt.event.InputEvent;

public class VentanaPremios extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel panel;
	private JPanel pnPuntos;
	private JPanel pnCarrito;
	private JPanel pnFinalizar;
	private JLabel lbPuntos;
	private JTextField txtPuntos;
	private JLabel lbCarrito;
	private JList<Regalo> listCarrito;
	private DefaultListModel<Regalo> modeloCarrito;
	private JButton btFinalizar;
	private JPanel pnFiltros;
	private JButton btTodos;
	private JButton btAlimentacion;
	private JButton btDeportes;
	private JButton btElectronica;
	private JButton btJuguetes;
	private JButton btViajesEX;
	private JPanel pnRegalos;
	
	private Entrega entrega;
	private Carta carta;
	private int puntos;
	private int puntosActual;
	private String codigo;
	
	private VentanaPuntos vPuntos;
	

	private AccionBotonPremio aB;
	private JButton btFiltroPrecio;
	private JButton btEliminar;
	private JPanel panel_1;
	private JSpinner spinnerCantidad;
	private JLabel lbUnidades;
	private JMenuBar menuBar;
	private JMenu mnPartida;
	private JMenuItem mntmNuevo;
	private JSeparator separator;
	private JMenuItem mntmSalir;
	private JMenu mnAyuda;
	private JMenuItem mntmAyuda;
	private JSeparator separator_1;
	private JMenuItem mntmAcercaDe;
	
	public VentanaPremios(int puntos, String codigo, VentanaPuntos vPuntos) {
		setTitle("Pantalla de Premios");
		aB = new AccionBotonPremio();
		cargaAyuda();
		
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				asociaImagenBotones();
			}
		});
		this.vPuntos = vPuntos;
		this.codigo = codigo;
		this.entrega = new Entrega();
		this.carta = new Carta();
		this.puntos = puntos;
		this.puntosActual = puntos;
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPremios.class.getResource("/img/regalo.jpg")));
		getContentPane().setBackground(new Color(154, 205, 50));
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(getPanel(), BorderLayout.EAST);
		getContentPane().add(getPnFiltros(), BorderLayout.WEST);
		setBounds(100, 100, 1000, 700);
		getTxtPuntos().setText(Integer.toString(puntos));
		getContentPane().add(getPnRegalos(), BorderLayout.CENTER);
		getContentPane().add(getMenuBar_1(), BorderLayout.NORTH);
	}
	
	public Entrega getEntrega() {
		return this.entrega;
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(new Color(204, 255, 102));
			panel.setLayout(new BorderLayout(0, 0));
			panel.add(getPnPuntos(), BorderLayout.NORTH);
			panel.add(getPnCarrito(), BorderLayout.CENTER);
			panel.add(getPnFinalizar(), BorderLayout.SOUTH);
		}
		return panel;
	}
	private JPanel getPnPuntos() {
		if (pnPuntos == null) {
			pnPuntos = new JPanel();
			pnPuntos.setBackground(new Color(204, 255, 102));
			pnPuntos.setLayout(new BorderLayout(0, 0));
			pnPuntos.add(getLbPuntos(), BorderLayout.NORTH);
			pnPuntos.add(getTxtPuntos());
		}
		return pnPuntos;
	}
	private JPanel getPnCarrito() {
		if (pnCarrito == null) {
			pnCarrito = new JPanel();
			pnCarrito.setBackground(new Color(204, 255, 102));
			pnCarrito.setLayout(new BorderLayout(0, 0));
			pnCarrito.add(getLbCarrito(), BorderLayout.NORTH);
			pnCarrito.add(getListCarrito());
			pnCarrito.add(getPanel_1(), BorderLayout.SOUTH);
		}
		return pnCarrito;
	}
	private JPanel getPnFinalizar() {
		if (pnFinalizar == null) {
			pnFinalizar = new JPanel();
			pnFinalizar.setBackground(new Color(204, 255, 102));
			pnFinalizar.add(getBtFinalizar());
		}
		return pnFinalizar;
	}
	private JLabel getLbPuntos() {
		if (lbPuntos == null) {
			lbPuntos = new JLabel("Puntos Restantes:");
			lbPuntos.setBackground(new Color(153, 204, 51));
			lbPuntos.setFont(new Font("Tahoma", Font.PLAIN, 18));
		}
		return lbPuntos;
	}
	private JTextField getTxtPuntos() {
		if (txtPuntos == null) {
			txtPuntos = new JTextField();
			txtPuntos.setHorizontalAlignment(SwingConstants.CENTER);
			txtPuntos.setBackground(new Color(204, 255, 255));
			txtPuntos.setFont(new Font("Tahoma", Font.PLAIN, 18));
			txtPuntos.setEditable(false);
			txtPuntos.setColumns(10);
		}
		return txtPuntos;
	}
	private JLabel getLbCarrito() {
		if (lbCarrito == null) {
			lbCarrito = new JLabel("Carrito:");
			lbCarrito.setBackground(new Color(153, 204, 51));
			lbCarrito.setFont(new Font("Tahoma", Font.PLAIN, 18));
		}
		return lbCarrito;
	}
	private JList<Regalo> getListCarrito() {
		if (listCarrito == null) {
			listCarrito = new JList<Regalo>();
			modeloCarrito = new DefaultListModel<Regalo>();
			listCarrito.setModel(modeloCarrito);
			listCarrito.setBackground(new Color(204, 255, 255));
			listCarrito.setFont(new Font("Tahoma", Font.PLAIN, 18));
		}
		return listCarrito;
	}
	private JButton getBtFinalizar() {
		if (btFinalizar == null) {
			btFinalizar = new JButton("Finalizar");
			btFinalizar.setMnemonic('F');
			btFinalizar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					puntosActual = puntos - entrega.getTotal();
					int respuestaSalir = JOptionPane.YES_OPTION;
					if(puntosActual>0) {
						int respuesta = JOptionPane.showConfirmDialog(null, "�Estas seguro de querer terminar? \tTodavia te quedan "+ puntosActual + " puntos.", "Terminar.", 1, 3);
						if(respuestaSalir == respuesta) {
							finalizar();
						}
					}else {
						int respuesta = JOptionPane.showConfirmDialog(null, "�Estas seguro de querer terminar? \tHa seleccionado"+ entrega.toString() + "productos.", "Terminar.", 1, 3);
						if(respuestaSalir == respuesta) {
							finalizar();
						}
					}
					
				}
			});
			btFinalizar.setBackground(new Color(153, 204, 204));
			btFinalizar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btFinalizar;
	}
	
	/**
	 * Metodo que finaliza la aplicacion guardando la entrega en un fichero.
	 */
	protected void finalizar() {
		if(!entrega.isVacio())
			entrega.finalizar(this.codigo);
		vPuntos.finalizar();
		this.dispose();
	}
	
	private JPanel getPnFiltros() {
		if (pnFiltros == null) {
			pnFiltros = new JPanel();
			pnFiltros.setBackground(new Color(204, 255, 102));
			pnFiltros.setLayout(new GridLayout(7, 1, 2, 2));
			pnFiltros.add(getBtTodos());
			pnFiltros.add(getBtAlimentacion());
			pnFiltros.add(getBtDeportes());
			pnFiltros.add(getBtElectronica());
			pnFiltros.add(getBtJuguetes());
			pnFiltros.add(getBtViajesEX());
			pnFiltros.add(getBtFiltroPrecio());
		}
		return pnFiltros;
	}
	private JButton getBtTodos() {
		if (btTodos == null) {
			btTodos = new JButton("Todo");
			btTodos.setMnemonic('T');
			btTodos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarTodo();
				}
			});
			btTodos.setBackground(new Color(153, 204, 204));
			btTodos.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btTodos;
	}
	private JButton getBtAlimentacion() {
		if (btAlimentacion == null) {
			btAlimentacion = new JButton("Alimentacion");
			btAlimentacion.setMnemonic('A');
			btAlimentacion.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarAlimentos();
				}
			});
			btAlimentacion.setVerticalTextPosition(SwingConstants.BOTTOM);
			btAlimentacion.setHorizontalTextPosition(SwingConstants.CENTER);
			btAlimentacion.setVerticalAlignment(SwingConstants.BOTTOM);
			btAlimentacion.setIcon(null);
			btAlimentacion.setBackground(new Color(153, 204, 204));
			btAlimentacion.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btAlimentacion;
	}
	private JButton getBtDeportes() {
		if (btDeportes == null) {
			btDeportes = new JButton("Deportes");
			btDeportes.setMnemonic('D');
			btDeportes.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarDeportes();
				}
			});
			btDeportes.setVerticalTextPosition(SwingConstants.BOTTOM);
			btDeportes.setHorizontalTextPosition(SwingConstants.CENTER);
			btDeportes.setVerticalAlignment(SwingConstants.BOTTOM);
			btDeportes.setBackground(new Color(153, 204, 204));
			btDeportes.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btDeportes;
	}
	private JButton getBtElectronica() {
		if (btElectronica == null) {
			btElectronica = new JButton("Electronica");
			btElectronica.setMnemonic('E');
			btElectronica.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarElectronica();
				}
			});
			btElectronica.setVerticalTextPosition(SwingConstants.BOTTOM);
			btElectronica.setHorizontalTextPosition(SwingConstants.CENTER);
			btElectronica.setVerticalAlignment(SwingConstants.BOTTOM);
			btElectronica.setBackground(new Color(153, 204, 204));
			btElectronica.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btElectronica;
	}
	private JButton getBtJuguetes() {
		if (btJuguetes == null) {
			btJuguetes = new JButton("Juguetes");
			btJuguetes.setMnemonic('J');
			btJuguetes.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarJuguetes();
				}
			});
			btJuguetes.setVerticalTextPosition(SwingConstants.BOTTOM);
			btJuguetes.setHorizontalTextPosition(SwingConstants.CENTER);
			btJuguetes.setVerticalAlignment(SwingConstants.BOTTOM);
			btJuguetes.setBackground(new Color(153, 204, 204));
			btJuguetes.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btJuguetes;
	}
	private JButton getBtViajesEX() {
		if (btViajesEX == null) {
			btViajesEX = new JButton("Viajes y Experiencias");
			btViajesEX.setMnemonic('V');
			btViajesEX.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarViajes();
				}
			});
			btViajesEX.setVerticalTextPosition(SwingConstants.BOTTOM);
			btViajesEX.setHorizontalTextPosition(SwingConstants.CENTER);
			btViajesEX.setVerticalAlignment(SwingConstants.BOTTOM);
			btViajesEX.setBackground(new Color(153, 204, 204));
			btViajesEX.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btViajesEX;
	}
	
	private JPanel getPnRegalos() {
		if (pnRegalos == null) {
			pnRegalos = new JPanel();
			pnRegalos.setBackground(new Color(204, 255, 102));
			pnRegalos.setLayout(new GridLayout(0, 4, 2, 2));
			
			crearBotonesTablero();
		}
		return pnRegalos;
	}
	
	/**
	 * Metodo que crea los botone del tablero, borrando todos los anteriores
	 */
	private void crearBotonesTablero() {
		//Me aseguro que no hay nada, si lo hay lo borro
		pnRegalos.removeAll();
		//Bucle iterando por los articulos que haya en la carta
		for (int i=0; i<carta.getRegalos().length; i++) {
			pnRegalos.add(nuevoBoton(i));
		}
	}
	
	/**
	 * Metodo que crea un boton en la posicion dada por parametro
	 * @param posicion en la que se coloca el boton
	 * @return el boton creado
	 */
	private JButton nuevoBoton(Integer posicion) {
		JButton boton = new JButton("");
		boton.setBackground(Color.white);
		boton.setBorder(new LineBorder(Color.GREEN, 2, true));
		boton.setToolTipText(carta.getListaArticulos().get(posicion).toString());
		boton.setActionCommand(posicion.toString());
		boton.addActionListener(aB);
		return boton;
	}

	/**
	 * Metodo que adapta el tama�o de la imagen segun el tama�o de la ventana
	 * @param boton al que adaptar la imagen
	 * @param rutaImagen imagen a adaptar
	 */
	private void setImagenAdaptada(JButton boton, String rutaImagen){
		 Image imgOriginal = new ImageIcon(getClass().getResource(rutaImagen)).getImage(); 
		 Image imgEscalada = imgOriginal.getScaledInstance(boton.getWidth(),boton.getHeight(), Image.SCALE_FAST);
		 ImageIcon icon = new ImageIcon(imgEscalada);
		 boton.setIcon(icon);
	}
	
	/**
	 * Metodo similar al anterior pero utilizando otros valores de escalado
	 * @param boton a escalar la imagen
	 * @param rutaImagen imagen a adaptar
	 */
	private void setImagenAdaptada2(JButton boton, String rutaImagen){
		 Image imgOriginal = new ImageIcon(getClass().getResource(rutaImagen)).getImage(); 
		 Image imgEscalada = imgOriginal.getScaledInstance((int)(boton.getWidth()*0.6),(int)(boton.getHeight()*0.6), Image.SCALE_FAST);
		 ImageIcon icon = new ImageIcon(imgEscalada);
		 boton.setIcon(icon);
	}
	

	/**
	 * Metodo que asocia las imagenes adaptadas a los botones creados
	 */
	private void asociaImagenBotones() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
		{
			JButton boton = (JButton) (pnRegalos.getComponents()[i]);
			setImagenAdaptada(boton,"/img/"+carta.getListaArticulos().get(i).getCodigo()+".png");
		}
		setImagenAdaptada2(btAlimentacion,"/img/A01.png");
		setImagenAdaptada2(btDeportes,"/img/D01.png");
		setImagenAdaptada2(btElectronica,"/img/E01.png");
		setImagenAdaptada2(btJuguetes,"/img/J01.png");
		setImagenAdaptada2(btViajesEX,"/img/V01.png");
	}

	
	/**
	 * Clase para que todos los botones del panel de premios utilicen la misma clase de evento
	 * en este caso seria mostrar la ventana del articulo correspondiente al boton presionado
	 *
	 */
	class AccionBotonPremio implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton bt = (JButton) e.getSource();
			int pos = Integer.parseInt(bt.getActionCommand());
			Regalo regalo = carta.getRegalos()[pos];
			if(puntosActual>= regalo.getPrecio()) {
				if(regalo.getCategoria().equals("V"))
					mostrarVentanaArticuloViaje(regalo);
				else
					mostrarVentanaArticulo(regalo, puntosActual);
			}
			else
				JOptionPane.showMessageDialog(null, "No tienes suficientes puntos para canjear este regalo.");
		}
	}
	
	/**
	 * Metodo que muestra la ventana de un articulo
	 * @param regalo articulo que se desea canjear
	 * @param puntosActual los puntos que posee el jugador
	 */
	private void mostrarVentanaArticulo(Regalo regalo, int puntosActual) {
		VentanaArticulo vArticulo = new VentanaArticulo(regalo, puntosActual, this);
		vArticulo.setLocationRelativeTo(this);
		vArticulo.setVisible(true);
	}
	
	/**
	 * Metodo que muestra la ventan de un articulo de tipo viaje y experiencias
	 * @param regalo que sedesea canjear
	 */
	private void mostrarVentanaArticuloViaje(Regalo regalo) {
		VentanaArticuloViaje vArticulo = new VentanaArticuloViaje(regalo, puntosActual, this);
		vArticulo.setLocationRelativeTo(this);
		vArticulo.setVisible(true);
	}
	
	/**
	 * Metodo que actualiza la ventana de premios despues de canjear un articulo
	 * @param regalo que se ha canjeado
	 * @param cantidad que se ha canjeado
	 */
	public void actualizarVentanaPremios(Regalo regalo, int cantidad) {
		puntosActual = puntos - entrega.getTotal();
		getTxtPuntos().setText(Integer.toString(puntosActual));//puntos
		System.out.println("FECHA:" + regalo.getFecha());
		System.out.println("Puntos: "+ puntos + " Actual: " + puntosActual);
		
		//entrega.add(regalo, cantidad); 
		
		for(int i=0;i<cantidad;i++)
			modeloCarrito.addElement(regalo);	
		
		actualizarLista();
	}
	
	/**
	 * Filtra para que esten disponibles todos los regalos del panel
	 */
	private void filtrarTodo() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
			((JButton) pnRegalos.getComponents()[i]).setEnabled(true);
	}
	
	/**
	 * Filtra para que este disponible solo los regalos de alimentos
	 */
	private void filtrarAlimentos() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
		{
			if (carta.getRegalos()[i].getCategoria().equals("A"))
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(true);
			else
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(false);
		}
	}
	
	/**
	 * Filtra para que este disponible solo los regalos de deportes
	 */
	private void filtrarDeportes() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
		{
			if (carta.getRegalos()[i].getCategoria().equals("D"))
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(true);
			else 
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(false);
		}
	}
	
	/**
	 * Filtra para que este disponible solo los regalos de electronica
	 */
	private void filtrarElectronica() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
		{
			if (carta.getRegalos()[i].getCategoria().equals("E"))
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(true);
			else 
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(false);
		}
	}
	
	/**
	 * Filtra para que este disponible solo los regalos de juguetes
	 */
	private void filtrarJuguetes() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
		{
			if (carta.getRegalos()[i].getCategoria().equals("J"))
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(true);
			else 
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(false);
		}
	}
	
	/**
	 * Filtra para que este disponible solo para regalos de viajes y experiencias
	 */
	private void filtrarViajes() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
		{
			if (carta.getRegalos()[i].getCategoria().equals("V"))
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(true);
			else
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(false);
		}
	}
	
	/**
	 * Filtra para que este disponible solo si tienes los puntos para canjearlo
	 */
	private void filtrarPrecio() {
		for (int i = 0; i < pnRegalos.getComponents().length; i++)
		{
			if (carta.getRegalos()[i].getPrecio()<=puntosActual)
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(true);
			else
				((JButton) (pnRegalos.getComponents()[i])).setEnabled(false);
		}
	}

	private JButton getBtFiltroPrecio() {
		if (btFiltroPrecio == null) {
			btFiltroPrecio = new JButton("Precio");
			btFiltroPrecio.setMnemonic('P');
			btFiltroPrecio.setBackground(new Color(153, 204, 204));
			btFiltroPrecio.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarPrecio();
				}
			});
			btFiltroPrecio.setVerticalAlignment(SwingConstants.BOTTOM);
			btFiltroPrecio.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btFiltroPrecio;
	}
	
	/**
	 * Metodo que actualiza la lista donde se muestran todos los articulos canjeados
	 */
	private void actualizarLista() {
		modeloCarrito = new DefaultListModel<Regalo>();
		for(int i=0;i<entrega.getListaEntrega().size();i++) {
			modeloCarrito.add(i, entrega.getListaEntrega().get(i));
			System.out.println("ACTUALIZAR LISTA: "+ entrega.getListaEntrega().get(i).getFecha());
			
		}
		listCarrito.setModel(modeloCarrito);
	}
	private JPanel getPanel_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBackground(new Color(204, 255, 102));
			panel_1.setLayout(new BorderLayout(0, 0));
			panel_1.add(getBtEliminar(), BorderLayout.SOUTH);
			panel_1.add(getSpinnerCantidad(), BorderLayout.CENTER);
			panel_1.add(getLbUnidades(), BorderLayout.NORTH);
		}
		return panel_1;
	}
	private JButton getBtEliminar() {
		if (btEliminar == null) {
			btEliminar = new JButton("Eliminar Regalo");
			btEliminar.setMnemonic('R');
			btEliminar.setBackground(new Color(153, 204, 204));
			btEliminar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int[] indices = listCarrito.getSelectedIndices();
					DefaultListModel<Regalo> model = (DefaultListModel<Regalo>) listCarrito.getModel();
					int cantidad = (int) getSpinnerCantidad().getValue();
					for(int indice: indices) {
						entrega.remove(model.get(indice), cantidad);
					}
					
					actualizarLista();
					puntosActual = puntos - entrega.getTotal();
					txtPuntos.setText("" + puntosActual);
					spinnerCantidad.setValue(1);
				}
			});
			btEliminar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return btEliminar;
	}
	@SuppressWarnings("removal")
	private JSpinner getSpinnerCantidad() {
		if (spinnerCantidad == null) {
			spinnerCantidad = new JSpinner();
			spinnerCantidad.setBackground(new Color(153, 204, 204));
			spinnerCantidad.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
			spinnerCantidad.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return spinnerCantidad;
	}
	private JLabel getLbUnidades() {
		if (lbUnidades == null) {
			lbUnidades = new JLabel("Unidades:");
			lbUnidades.setDisplayedMnemonic('U');
			lbUnidades.setLabelFor(getSpinnerCantidad());
			lbUnidades.setBackground(new Color(153, 204, 51));
			lbUnidades.setFont(new Font("Tahoma", Font.PLAIN, 16));
		}
		return lbUnidades;
	}
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnPartida());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnPartida() {
		if (mnPartida == null) {
			mnPartida = new JMenu("Partida");
			mnPartida.setMnemonic('P');
			mnPartida.add(getMntmNuevo());
			mnPartida.add(getSeparator());
			mnPartida.add(getMntmSalir());
		}
		return mnPartida;
	}
	@SuppressWarnings("deprecation")
	private JMenuItem getMntmNuevo() {
		if (mntmNuevo == null) {
			mntmNuevo = new JMenuItem("Nuevo");
			mntmNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					finalizar();
				}
			});
			mntmNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
			mntmNuevo.setMnemonic('N');
		}
		return mntmNuevo;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	@SuppressWarnings("deprecation")
	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(ABORT);
				}
			});
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_MASK));
			mntmSalir.setMnemonic('S');
		}
		return mntmSalir;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('A');
			mnAyuda.add(getMntmAyuda());
			mnAyuda.add(getSeparator_1());
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMntmAyuda() {
		if (mntmAyuda == null) {
			mntmAyuda = new JMenuItem("Ayuda");
			mntmAyuda.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
			mntmAyuda.setMnemonic('A');
		}
		return mntmAyuda;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca De...");
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Esta aplicacion ha sido realizada por\n Fernando Jos� Gonz�lez Sierra", "Acerca De...", 1, null);
				}
			});
		}
		return mntmAcercaDe;
	}
	
	/**
	 * Metodo que carga la ayuda de la aplicacion y se le asigna el boton F1 para abrirla
	 */
	private void cargaAyuda(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"regalos", hs); //activar F1
		   hb.enableHelpOnButton(getMntmAyuda(), "regalos", hs);
		   
		   //hb.enableHelp(getBtSiguiente(), "siguiente", hs); //ayuda contextual
		 }
}
