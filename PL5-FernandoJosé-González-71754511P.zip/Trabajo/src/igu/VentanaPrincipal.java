package igu;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import logica.FileUtil;
import logica.Juego;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

import java.awt.event.InputEvent;
import javax.swing.ImageIcon;

public class VentanaPrincipal extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JLabel lblTitulo;
	private JLabel lbCodigo;
	private JTextField txtCodigo;
	private JButton btSiguiente;
	
	private ProcesaTecla pT;
	
	private JMenuBar menuBar;
	private JMenu mnPartida;
	private JMenu mnAyuda;
	private JMenuItem mntmNuevo;
	private JSeparator separator;
	private JMenuItem mntmSalir;
	private JMenuItem mntmAyuda;
	private JSeparator separator_1;
	private JMenuItem mntmAcercaDe;
	private JLabel lblNewLabel;
	
	//private Juego juego;
	
	public VentanaPrincipal() {
		pT = new ProcesaTecla();
		cargaAyuda();
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/regalo.jpg")));
		setTitle("Ventana de Registro");
		setResizable(false);
		getContentPane().setBackground(new Color(204, 255, 102));
		setBounds(100, 100, 629, 468);
		getContentPane().setLayout(null);
		getContentPane().add(getLblTitulo());
		getContentPane().add(getLbCodigo());
		getContentPane().add(getTxtCodigo());
		getContentPane().add(getBtSiguiente());
		getContentPane().add(getLblNewLabel());
		setJMenuBar(getMenuBar_1());
	}
	
	/**
	 * Metodo para reiniciar la aplicacion, normalmente llamado desde la VentanaPuntos.
	 */
	protected void reiniciar() {
		getTxtCodigo().setText("");
		getTxtCodigo().grabFocus();
	}
	
	private JLabel getLblTitulo() {
		if (lblTitulo == null) {
			lblTitulo = new JLabel("EL PANEL DE REGALOS");
			lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 32));
			lblTitulo.setBounds(140, 95, 353, 92);
		}
		return lblTitulo;
	}
	private JLabel getLbCodigo() {
		if (lbCodigo == null) {
			lbCodigo = new JLabel("CODIGO:");
			lbCodigo.setDisplayedMnemonic('C');
			lbCodigo.setToolTipText("");
			lbCodigo.setLabelFor(getTxtCodigo());
			lbCodigo.setFont(new Font("Tahoma", Font.PLAIN, 16));
			lbCodigo.setBounds(66, 187, 74, 63);
		}
		return lbCodigo;
	}
	private JTextField getTxtCodigo() {
		if (txtCodigo == null) {
			txtCodigo = new JTextField();
			txtCodigo.setFont(new Font("Tahoma", Font.PLAIN, 16));
			txtCodigo.setBackground(new Color(204, 255, 255));
			txtCodigo.setBounds(150, 198, 313, 41);
			txtCodigo.setColumns(10);
			txtCodigo.addKeyListener(pT);
		}
		return txtCodigo;
	}
	private JButton getBtSiguiente() {
		if (btSiguiente == null) {
			btSiguiente = new JButton("Siguiente");
			btSiguiente.setMnemonic('S');
			btSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					comprobarJugador();
					//mostrarVentanaPuntos();
				}
			});
			btSiguiente.setBackground(new Color(176, 196, 222));
			btSiguiente.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btSiguiente.setBounds(218, 250, 162, 31);
		}
		return btSiguiente;
	}
	
	/**
	 * Metodo que comprueba que el identificador del jugador este en el fichero y pueda jugar.
	 */
	private void comprobarJugador() {
		String codigo = getTxtCodigo().getText().toUpperCase();
		if(codigo.equals(""))
			JOptionPane.showMessageDialog(null, "No has rellenado el campo de Codigo:");
		else if(FileUtil.cargarCliente("clientes", codigo))
			mostrarVentanaPuntos();
		else
			JOptionPane.showMessageDialog(null, "No tienes partidas disponibles para ese identificador.\nIntentelo de nuevo.");
	}
	
	/**
	 * Metodo que crea un Juego nuevo y lo manda por parametro a la ventana de puntos.
	 */
	private void mostrarVentanaPuntos(){
		Juego juego = new Juego();
		VentanaPuntos vPuntos = new VentanaPuntos(juego, getTxtCodigo().getText(), this);
		vPuntos.setLocationRelativeTo(this);
		vPuntos.setVisible(true);
	}
	
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnPartida());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnPartida() {
		if (mnPartida == null) {
			mnPartida = new JMenu("Partida");
			mnPartida.setMnemonic('P');
			mnPartida.add(getMntmNuevo());
			mnPartida.add(getSeparator());
			mnPartida.add(getMntmSalir());
		}
		return mnPartida;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('A');
			mnAyuda.add(getMntmAyuda());
			mnAyuda.add(getSeparator_1());
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}
	@SuppressWarnings("deprecation")
	private JMenuItem getMntmNuevo() {
		if (mntmNuevo == null) {
			mntmNuevo = new JMenuItem("Nuevo");
			mntmNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					reiniciar();
				}
			});
			mntmNuevo.setMnemonic('N');
			mntmNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
		}
		return mntmNuevo;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	@SuppressWarnings("deprecation")
	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(ABORT);
				}
			});
			mntmSalir.setMnemonic('S');
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_MASK));
		}
		return mntmSalir;
	}
	private JMenuItem getMntmAyuda() {
		if (mntmAyuda == null) {
			mntmAyuda = new JMenuItem("Ayuda");
			mntmAyuda.setMnemonic('A');
			mntmAyuda.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
		}
		return mntmAyuda;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca De...");
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Esta aplicacion ha sido realizada por\n Fernando Jos� Gonz�lez Sierra", "Acerca De...", 1, null);
				}
			});
		}
		return mntmAcercaDe;
	}
	
	/**
	 * Clase adaptadora de Key que cuando se pulsa el boton enter,
	 * se realiza la accion por defecto en este caso comprobar y avanzar
	 * a la siguiente ventana.
	 */
	class ProcesaTecla extends KeyAdapter {
		public void keyTyped(KeyEvent e) {
			char teclaPulsada = e.getKeyChar();
			if (teclaPulsada == KeyEvent.VK_ENTER)
				comprobarJugador();
		}
	}
	
	/**
	 * Metodo que carga la ayuda de la aplicacion y se le asigna el boton F1 para abrirla
	 */
	private void cargaAyuda(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"introduccion", hs); //activar F1
		   hb.enableHelpOnButton(getMntmAyuda(), "introduccion", hs);
		   
		   
		   hb.enableHelp(getBtSiguiente(), "codigo", hs); //ayuda contextual
		 }
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("");
			lblNewLabel.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/ESTASI.jpg")));
			lblNewLabel.setBounds(448, 295, 147, 111);
		}
		return lblNewLabel;
	}
}
