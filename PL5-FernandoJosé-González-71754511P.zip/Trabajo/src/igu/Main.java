package igu;

import java.awt.EventQueue;
import java.util.Properties;

import javax.swing.UIManager;

public class Main {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Properties props = new Properties();
					props.put("logoString", "");
					UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
					
					VentanaPrincipal frame = new VentanaPrincipal();
					//VentanaPuntos frame = new VentanaPuntos();
					//VentanaPremios frame = new VentanaPremios();
					//VentanaArticulo frame = new VentanaArticulo();
					//VentanaArticuloViaje frame = new VentanaArticuloViaje();
					
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
