package igu;

import javax.swing.JFrame;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import logica.Juego;

import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import java.awt.event.InputEvent;

public class VentanaPuntos extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel pnCasillas;
	private JPanel pnBoton;
	private JPanel pnSiguiente;
	private JButton btSiguiente;
	private JPanel pnContenedor;
	private JPanel pnPuntos;
	private JPanel pnTiradasRestantes;
	private JLabel lbPuntos;
	private JLabel lbTiradasRestantes;
	private JTextField txtPuntos;
	private JTextField txtTiradasRestantes;
	
	private ActionButton aB;
	
	private Juego juego;
	private String codigo;
	
	private VentanaPrincipal vPrincipal;
	private JMenuBar menuBar;
	private JMenu mnPartida;
	private JMenuItem mntmNuevo;
	private JSeparator separator;
	private JMenuItem mntmSalir;
	private JMenu mnAyuda;
	private JMenuItem mntmAyuda;
	private JSeparator separator_1;
	private JMenuItem mntmAcercaDe;
	
	public VentanaPuntos(Juego juego, String codigo, VentanaPrincipal vPrincipal) {
		setTitle("Pantalla de Puntos");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPuntos.class.getResource("/img/regalo.jpg")));
		this.vPrincipal = vPrincipal;
		this.juego = juego;
		this.codigo = codigo;
		aB = new ActionButton();
		cargaAyuda();
		getContentPane().setBackground(new Color(154, 205, 50));
		getContentPane().setLayout(new BorderLayout(0, 0));
		getContentPane().add(getPnCasillas(), BorderLayout.CENTER);
		getContentPane().add(getPnBoton(), BorderLayout.EAST);
		getContentPane().add(getMenuBar_1(), BorderLayout.NORTH);
		setBounds(100, 100, 729, 465);
		crearCasillas();
	}
	private JPanel getPnCasillas() {
		if (pnCasillas == null) {
			pnCasillas = new JPanel();
			pnCasillas.setBackground(new Color(204, 255, 102));
			pnCasillas.setLayout(new GridLayout(5, 5, 1, 1));
		}
		return pnCasillas;
	}
	private JPanel getPnBoton() {
		if (pnBoton == null) {
			pnBoton = new JPanel();
			pnBoton.setBackground(new Color(204, 255, 102));
			pnBoton.setLayout(new BorderLayout(0, 0));
			pnBoton.add(getPnSiguiente(), BorderLayout.SOUTH);
			pnBoton.add(getPnContenedor(), BorderLayout.CENTER);
		}
		return pnBoton;
	}
	private JPanel getPnSiguiente() {
		if (pnSiguiente == null) {
			pnSiguiente = new JPanel();
			pnSiguiente.setBackground(new Color(204, 255, 102));
			pnSiguiente.add(getBtSiguiente());
		}
		return pnSiguiente;
	}
	private JButton getBtSiguiente() {
		if (btSiguiente == null) {
			btSiguiente = new JButton("Siguiente");
			btSiguiente.setMnemonic('S');
			btSiguiente.setBackground(new Color(153, 204, 204));
			btSiguiente.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btSiguiente.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					compruebaSiguiente();
				}
			});
		}
		return btSiguiente;
	}
	
	/**
	 * Metodo que comprueba que tienes tiradas todavia y si es asi avisa al usuario, en caso de querer continuar
	 * se avanza a la ventana de premios
	 */
	private void compruebaSiguiente() {
		if(juego.getTiradasRestantes()>0) {
			int continuar = JOptionPane.YES_OPTION;
			int eleccion = JOptionPane.showConfirmDialog(null, "Todavia tienes " + juego.getTiradasRestantes()+ " tiradas restantes."
					+ "�Estas seguro de que quieres continuar al panel de premios?");
			if(continuar==eleccion)
				mostrarVentanaPremios();
		}
		else
			mostrarVentanaPremios();
	}
	/**
	 * Metodo que muestra la ventana de premios, centrado con respecto a la actual.
	 */
	private void mostrarVentanaPremios() {
		VentanaPremios vPremios = new VentanaPremios(juego.getPuntos(), this.codigo, this);
		vPremios.setLocationRelativeTo(this);
		vPremios.setVisible(true);
		
	}
	
	private JPanel getPnContenedor() {
		if (pnContenedor == null) {
			pnContenedor = new JPanel();
			pnContenedor.setBackground(new Color(204, 255, 102));
			pnContenedor.setLayout(new GridLayout(2, 0, 0, 3));
			pnContenedor.add(getPnPuntos());
			pnContenedor.add(getPnTiradasRestantes());
		}
		return pnContenedor;
	}
	private JPanel getPnPuntos() {
		if (pnPuntos == null) {
			pnPuntos = new JPanel();
			pnPuntos.setBackground(new Color(204, 255, 102));
			pnPuntos.setLayout(new BorderLayout(0, 0));
			pnPuntos.add(getLbPuntos(), BorderLayout.NORTH);
			pnPuntos.add(getTxtPuntos(), BorderLayout.CENTER);
		}
		return pnPuntos;
	}
	
	private JPanel getPnTiradasRestantes() {
		if (pnTiradasRestantes == null) {
			pnTiradasRestantes = new JPanel();
			pnTiradasRestantes.setBackground(new Color(204, 255, 102));
			pnTiradasRestantes.setLayout(new BorderLayout(0, 0));
			pnTiradasRestantes.add(getLbTiradasRestantes(), BorderLayout.NORTH);
			pnTiradasRestantes.add(getTxtTiradasRestantes(), BorderLayout.CENTER);
		}
		return pnTiradasRestantes;
	}
	
	private JLabel getLbPuntos() {
		if (lbPuntos == null) {
			lbPuntos = new JLabel("Puntos:");
			lbPuntos.setBackground(new Color(153, 204, 51));
			lbPuntos.setFont(new Font("Tahoma", Font.PLAIN, 18));
		}
		return lbPuntos;
	}
	
	private JLabel getLbTiradasRestantes() {
		if (lbTiradasRestantes == null) {
			lbTiradasRestantes = new JLabel("Tiradas Restantes:");
			lbTiradasRestantes.setBackground(new Color(153, 204, 51));
			lbTiradasRestantes.setFont(new Font("Tahoma", Font.PLAIN, 18));
		}
		return lbTiradasRestantes;
	}
	
	private JTextField getTxtPuntos() {
		if (txtPuntos == null) {
			txtPuntos = new JTextField();
			txtPuntos.setBackground(new Color(204, 255, 255));
			txtPuntos.setHorizontalAlignment(SwingConstants.CENTER);
			txtPuntos.setFont(new Font("Tahoma", Font.PLAIN, 18));
			txtPuntos.setEditable(false);
			txtPuntos.setColumns(10);
		}
		return txtPuntos;
	}
	
	private JTextField getTxtTiradasRestantes() {
		if (txtTiradasRestantes == null) {
			txtTiradasRestantes = new JTextField();
			txtTiradasRestantes.setBackground(new Color(204, 255, 255));
			txtTiradasRestantes.setHorizontalAlignment(SwingConstants.CENTER);
			txtTiradasRestantes.setFont(new Font("Tahoma", Font.PLAIN, 18));
			txtTiradasRestantes.setEditable(false);
			txtTiradasRestantes.setColumns(10);
		}
		return txtTiradasRestantes;
	}
	/**
	 * Metodo que crea un bucle del tama�o del tablero para crear todas las 
	 * casillas necesarias y a�adirlas al panel.
	 */
	private void crearCasillas() {
		for(int i=0;i<Juego.tamTablero;i++) 
			getPnCasillas().add(nuevaCasilla(i));
	}
	/**
	 * Metodo que crea una nueva casilla con una posicion como parametro,
	 * se le a�ade un valor al actionCommand para identificarse dentro del sistema,
	 * y utiliza una foto dependiendo de que tipo de casilla sea.
	 * @param pos en la que esta dentro del tablero
	 * @return el nuevo boton
	 */
	private JButton nuevaCasilla(int pos) {
		JButton nuevo = new JButton("");
		nuevo.setBackground(Color.white);
		nuevo.setActionCommand(String.valueOf(pos));
		nuevo.setIcon(ImagenFactoria.getImagen());
		nuevo.setBorder(new LineBorder(Color.green,1));
		nuevo.addActionListener(aB);
		return nuevo;
	}
	
	/**
	 * Metodo que cambia de habilitada a desabilitada y viceversa dependiendo del parametro dado.
	 * @param estado si es true habilita todo el tablero, false lo desactiva.
	 */
	private void habilitarTablero(boolean estado) {
		for(int i=0;i<getPnCasillas().getComponents().length;i++) 
			getPnCasillas().getComponents()[i].setEnabled(estado);
	}
	
	/**
	 * Metodo que destapa la casilla de la posicion dada por parametro cambiando su imagen.
	 * Comprueba que no queden tiradas para destapar.
	 * Modifica los puntos y las tiradas restantes.
	 * Y comprueba si termino la partida, si es asi, muestra un mensaje para avanzar mas rapido por la aplicacion.
	 * @param posicion de la casilla a destapar
	 */
	private void destaparCasilla(int posicion) {
		ImageIcon imagen = ImagenFactoria.getImagen(juego.getTablero().getCasillas()[posicion]);
		((JButton)getPnCasillas().getComponent(posicion)).setIcon(imagen);
		((JButton)getPnCasillas().getComponent(posicion)).setDisabledIcon(imagen);
		((JButton)getPnCasillas().getComponent(posicion)).setEnabled(false);
		
		if(juego.getTiradasRestantes()>0)
			juego.tirada(posicion);
		
		getTxtPuntos().setText(Integer.toString(juego.getPuntos()));
		getTxtTiradasRestantes().setText(Integer.toString(juego.getTiradasRestantes()));
		
		if(juego.isPartidaFinalizada()) {
			habilitarTablero(false);
			int continuar = JOptionPane.OK_OPTION;
			int eleccion = JOptionPane.showConfirmDialog(null, "Ya no te quedan tiradas, continua a la seccion de premios.", "Terminaste de Jugar.", 2, 3);
			if(continuar == eleccion)
				mostrarVentanaPremios();
		}	
	}
	
	/**
	 * Metodo que finaliza la aplicacion cerrando esta ventana y avisando del reinicio a la ventana principal
	 */
	protected void finalizar() {
		vPrincipal.reiniciar();
		this.dispose();
	}
	
	/**
	 * Clase que implementa un ActionListener para la realizacion de un evento comun a muchos componentes,
	 * en este caso es al panel de puntos ya que todos los botones del panel se destapan.
	 *
	 */
	class ActionButton implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton bt = (JButton) e.getSource();
			destaparCasilla(Integer.parseInt(bt.getActionCommand()));
		}
	}
	

	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnPartida());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnPartida() {
		if (mnPartida == null) {
			mnPartida = new JMenu("Partida");
			mnPartida.setMnemonic('P');
			mnPartida.add(getMntmNuevo());
			mnPartida.add(getSeparator());
			mnPartida.add(getMntmSalir());
		}
		return mnPartida;
	}
	@SuppressWarnings("deprecation")
	private JMenuItem getMntmNuevo() {
		if (mntmNuevo == null) {
			mntmNuevo = new JMenuItem("Nuevo");
			mntmNuevo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					finalizar();
				}
			});
			mntmNuevo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
			mntmNuevo.setMnemonic('N');
		}
		return mntmNuevo;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	@SuppressWarnings("deprecation")
	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(ABORT);
				}
			});
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_MASK));
			mntmSalir.setMnemonic('S');
		}
		return mntmSalir;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('A');
			mnAyuda.add(getMntmAyuda());
			mnAyuda.add(getSeparator_1());
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMntmAyuda() {
		if (mntmAyuda == null) {
			mntmAyuda = new JMenuItem("Ayuda");
			mntmAyuda.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
			mntmAyuda.setMnemonic('A');
		}
		return mntmAyuda;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca De...");
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Esta aplicacion ha sido realizada por\n Fernando Jos� Gonz�lez Sierra", "Acerca De...", 1, null);
				}
			});
		}
		return mntmAcercaDe;
	}
	
	/**
	 * Metodo que carga la ayuda de la aplicacion y se le asigna el boton F1 para abrirla
	 */
	private void cargaAyuda(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"puntos", hs); //activar F1
		   hb.enableHelpOnButton(getMntmAyuda(), "puntos", hs);
		   
		   hb.enableHelp(getBtSiguiente(), "siguiente", hs); //ayuda contextual
		 }
}
