package logica;

import java.io.*;
import java.util.*;

public abstract class FileUtil {

	public static void loadFile(String nombreFicheroEntrada, List<Regalo> listaCatalogo) {

		String linea;
		String[] datosRegalo = null;

		try {
			BufferedReader fichero = new BufferedReader(new FileReader(nombreFicheroEntrada));
			while (fichero.ready()) {
				linea = fichero.readLine();
				datosRegalo = linea.split("@");
				listaCatalogo.add(new Regalo(datosRegalo[0], datosRegalo[1], datosRegalo[2], datosRegalo[3],
						Integer.parseInt(datosRegalo[4]), 0, "", ""));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}

	public static void saveToFile(String nombreFicheroSalida, String idCliente, List<Regalo> listaRegalos) {
		try {
			BufferedWriter fichero = new BufferedWriter(new FileWriter("files/" + nombreFicheroSalida + ".dat"));
			for(Regalo r: listaRegalos) {
				for(int i=0;i<r.getUnidades();i++) {
					if(r.getCategoria().equals("V")) {
						fichero.write(idCliente + "@" + r.getCodigo() + "@" + r.getFecha());
						if(!r.getObservaciones().equals(""))
							fichero.write("@" + r.getObservaciones() + "\n");
						else
							fichero.write("\n");
					}
					else
						fichero.write(idCliente + "@" + r.getCodigo()+ "\n");
				}
			}
			fichero.close();
		}

		catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha podido guardar");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida");
		}
	}
	
	
	public static boolean cargarCliente(String nombreFichero, String codigo) {
		String linea;
		String[] datosCliente = null;
		boolean puedeJugar = false;

		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/" + nombreFichero+ ".dat"));
			BufferedWriter escribirFichero = new BufferedWriter(new FileWriter("files/nuevoFichero.dat"));
			while (fichero.ready()) {
				linea = fichero.readLine();
				datosCliente = linea.split("@");
				if(datosCliente[0].equals(codigo) && Integer.parseInt(datosCliente[2])>0) {
					puedeJugar = true;
					String nuevaLinea = datosCliente[0] + "@" + datosCliente[1] + "@0\n";
					
					escribirFichero.write(nuevaLinea);
				}else
					escribirFichero.write(linea + "\n");
			}
			fichero.close();
			escribirFichero.close();
			
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha encontrado.");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
		
		copia("files/nuevoFichero.dat", "files/" + nombreFichero+ ".dat");
		return puedeJugar;
		
	}
	
	public static void copia (String ficheroOriginal, String ficheroCopia)
	{
		try
		{
            // Se abre el fichero original para lectura
			FileInputStream fileInput = new FileInputStream(ficheroOriginal);
			BufferedInputStream bufferedInput = new BufferedInputStream(fileInput);
			
			// Se abre el fichero donde se har� la copia
			FileOutputStream fileOutput = new FileOutputStream (ficheroCopia);
			BufferedOutputStream bufferedOutput = new BufferedOutputStream(fileOutput);
			
			// Bucle para leer de un fichero y escribir en el otro.
			byte [] array = new byte[1000];
			int leidos = bufferedInput.read(array);
			while (leidos > 0)
			{
				bufferedOutput.write(array,0,leidos);
				leidos=bufferedInput.read(array);
			}

			// Cierre de los ficheros
			bufferedInput.close();
			bufferedOutput.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
