package logica;

public class Casilla_Puntos_1000 extends Casilla_Puntos{

	public Casilla_Puntos_1000() {
		setPuntos(1000);
	}
	
}
