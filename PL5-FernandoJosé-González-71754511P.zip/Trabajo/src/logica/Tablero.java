package logica;

public class Tablero {
	
	public static final int DIM = 25;
	
	private Casilla[] casillas;
	
	public Tablero() {
		casillas = new Casilla[DIM];
		for (int i=0;i<DIM;i++)
				casillas[i] = new Casilla_Vacio();
		
		colocaMultiplica();
		colocaEspecial();
		colocaEspecial();
		colocaPuntos();
	}
	
	private void colocaMultiplica() {
		int pos = (int) (Math.random() * DIM);
		System.out.println("Multiplicar en: "+ pos);
		casillas[pos] = new Casilla_Multiplica();	
	}

	private void colocaEspecial() {
		boolean coloca = false;
		int posEspecial = 0;
		while(!coloca) { 
			posEspecial = (int) (Math.random()* DIM);
			if(casillas[posEspecial] instanceof Casilla_Vacio)
				coloca=true;	
		}
		
		System.out.println("Especial en: "+ posEspecial);
		casillas[posEspecial] = new Casilla_Especial();
	}

	private void colocaPuntos() {
		for(int i=0;i<8;i++) {
			colocaPunto(50);
			if(i<5)
				colocaPunto(250);	
		}
		colocaPunto(1000);
	}
	
	private void colocaPunto(int puntos) {
		boolean coloca = false;
		int posColocar = 0;
		while(!coloca) {
			posColocar = (int) (Math.random()* DIM);
			if(casillas[posColocar] instanceof Casilla_Vacio)
				coloca=true;
		}
		if(puntos == 50)
			casillas[posColocar] = new Casilla_Puntos_50();
		if(puntos == 250)
			casillas[posColocar] = new Casilla_Puntos_250();
		if(puntos == 1000)
			casillas[posColocar] = new Casilla_Puntos_1000();
		
		System.out.println(puntos +  " puntos en " + posColocar);
	}

	public Casilla[] getCasillas() {
		return casillas;
	}

}
