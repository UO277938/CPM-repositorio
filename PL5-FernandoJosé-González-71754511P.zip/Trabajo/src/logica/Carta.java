package logica;

import java.util.ArrayList;
import java.util.List;

public class Carta {

	private static final String FICHERO_REGALOS = "files/regalos.dat";
	private List<Regalo> listaRegalos = null;

	public Carta() {
		listaRegalos = new ArrayList<Regalo>();
		cargarRegalos();
	}

	private void cargarRegalos() {
		FileUtil.loadFile(FICHERO_REGALOS, listaRegalos);
	}

	public Regalo[] getRegalos() {
		Regalo[] articulos = listaRegalos.toArray(new Regalo[listaRegalos.size()]);
		return articulos;
	}

	public List<Regalo> getListaArticulos() {
		return listaRegalos;
	}
}
