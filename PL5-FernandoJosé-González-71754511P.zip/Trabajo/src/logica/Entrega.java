package logica;

import java.util.ArrayList;
import java.util.List;

public class Entrega {

	private List<Regalo> listaEntrega;


	public Entrega() {
		listaEntrega = new ArrayList<Regalo>();
		inicializar();
	}
	
	public List<Regalo> getListaEntrega(){
		return this.listaEntrega;
	}

	public void inicializar() {
		listaEntrega.clear();
	}

	public boolean isVacio() {
		return listaEntrega.size() == 0;
	}

	public void add(Regalo regaloDelCatalogo, int unidades) {
		Regalo regaloEnPedido = null;
		System.out.println("ADD: "+ regaloDelCatalogo.getFecha());
		

		for (Regalo a : listaEntrega) {
			if (a.getCodigo().equals(regaloDelCatalogo.getCodigo())) {
				regaloEnPedido = a;
				regaloEnPedido.setUnidades(regaloEnPedido.getUnidades() + unidades);
				break;
			}
		}

		if (regaloEnPedido == null) {
			Regalo regaloAPedido = new Regalo(regaloDelCatalogo);
			regaloAPedido.setUnidades(unidades);
			System.out.println("REGALO A PEDIDO: "+ regaloAPedido.getFecha());
			listaEntrega.add(regaloAPedido);
		}

	}

	public void remove(Regalo regalo, int unidades) {
		Regalo regaloEnPedido = null;
		for (Regalo a : listaEntrega) {
			if (a.getCodigo().equals(regalo.getCodigo()))
				regaloEnPedido = a;
		}
		if (regaloEnPedido != null) {
			int totalUnidades = regaloEnPedido.getUnidades() - unidades;
			if (totalUnidades <= 0) {
				listaEntrega.remove(regaloEnPedido);
			} else
				regaloEnPedido.setUnidades(totalUnidades);
		}
	}

	public int getTotal() {
		int precio = 0;
		for (Regalo a : listaEntrega) {
			precio += a.getPrecio() * a.getUnidades();
		}
		return precio;
	}

	public int buscarUnidades(Regalo articuloSeleccionado) {
		for (Regalo a : listaEntrega) {
			if (a.getCodigo().equals(articuloSeleccionado.getCodigo()))
				return (a.getUnidades());
		}
		return 0;
	}

	public String toString() {
		String strPedido = "";
		for (Regalo a : listaEntrega) {
			strPedido = strPedido + a.getDenominacion() + " - " + a.getUnidades() + (" uds.") + ("\n");
		}
		strPedido = strPedido + ("Total: " +  getTotal()) + ("\n");
		return strPedido;
	}
	
	public void finalizar(String clienteCodigo) {
		for(Regalo r: listaEntrega) {
			for(int i=0;i<r.getUnidades();i++)
				System.out.println("AHORA AL FINAL:" + r.getFecha() + "fa: "+ r.getObservaciones());
				FileUtil.saveToFile("entregas", clienteCodigo, listaEntrega);
		}
	}
}
