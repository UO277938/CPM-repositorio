package logica;

public class Casilla_Puntos extends Casilla {

}
