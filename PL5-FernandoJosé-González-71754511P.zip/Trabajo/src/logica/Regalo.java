package logica;

public class Regalo {

	private String codigo;
	private String categoria;
	private String denominacion;
	private String descripcion;
	private int precio;
	private int unidades;
	
	private String fecha;
	private String observaciones;
	
	
	public Regalo(String codigo, String categoria, String denominacion, String descripcion, int precio, int unidades, String fecha, String observaciones) {
		this.codigo = codigo;
		this.categoria = categoria;
		this.denominacion = denominacion;
		this.descripcion = descripcion;
		this.precio = precio;
		this.unidades = unidades;
		this.fecha = fecha;
		this.observaciones = observaciones;
	}
	

	public Regalo(Regalo otroRegalo) {
		this(otroRegalo.codigo, otroRegalo.categoria, otroRegalo.denominacion, otroRegalo.descripcion, otroRegalo.precio,
				otroRegalo.unidades, otroRegalo.fecha, otroRegalo.observaciones);
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDenominacion() {
		return denominacion;
	}

	public void setDenominacion(String denominacion) {
		this.denominacion = denominacion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public int getUnidades() {
		return unidades;
	}

	public void setUnidades(int unidades) {
		this.unidades = unidades;
	}
	
	
	public String getFecha() {
		return fecha;
	}


	public void setFecha(String fecha) {
		this.fecha = fecha;
	}


	public String getObservaciones() {
		return observaciones;
	}


	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}


	public String toString() {
		String strRegalo;
		strRegalo = this.categoria + " - " + this.denominacion + " - " + this.precio + " puntos";
		if (this.unidades != 0) {
			strRegalo += " (" + this.unidades + " uds." + ")";
		}
		return strRegalo;
	}
	
}
