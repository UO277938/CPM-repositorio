package logica;

public class Casilla_Vacio extends Casilla {

	public Casilla_Vacio() {
		setPuntos(0);
	}
}
