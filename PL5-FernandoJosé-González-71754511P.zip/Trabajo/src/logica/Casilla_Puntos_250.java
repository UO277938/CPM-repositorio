package logica;

public class Casilla_Puntos_250 extends Casilla_Puntos{

	public Casilla_Puntos_250() {
		setPuntos(250);
	}
}
