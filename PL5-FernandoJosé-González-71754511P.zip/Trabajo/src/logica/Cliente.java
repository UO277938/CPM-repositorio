package logica;

public class Cliente {

	private String codigo;
	private String nombre;
	private int puedeJugar;
	
	public Cliente(String codigo, String nombre, int puedeJugar) {
		
		this.codigo=codigo; 
		this.nombre = nombre;
		this.puedeJugar = puedeJugar;
	}
	
	
	public int getPuedeJugar() {
		return puedeJugar;
	}


	public void setPuedeJugar(int puedeJugar) {
		this.puedeJugar = puedeJugar;
	}


	public String toString() {
		String strCliente;
		
		strCliente = this.codigo + "@"+ this.nombre + "@" + this.puedeJugar;
		return strCliente;
	}
}
