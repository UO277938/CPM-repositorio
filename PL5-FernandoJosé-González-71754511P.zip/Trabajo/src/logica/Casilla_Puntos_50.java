package logica;

public class Casilla_Puntos_50 extends Casilla_Puntos {

	public Casilla_Puntos_50() {
		setPuntos(50);
	}
}
