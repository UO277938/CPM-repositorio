package logica;

public class Casilla_Especial extends Casilla{

}
