package logica;

public class Casilla_Multiplica extends Casilla{

}
