package logica;

public class Juego {

	public static final int maxTiradas = 3;
	public static final int tamTablero = 25;
	
	private int puntos;
	private int tiradas;
	private Tablero tablero; 
	
	
	
	public Juego(){
		inicializarJuego();
	}
	
	public void inicializarJuego(){
		tablero = new Tablero();
		puntos = 0;
		tiradas = maxTiradas;
	}

	public Tablero getTablero() {
		return tablero;
	}
	
	public int getTiradasRestantes() {
		return tiradas;
	}
	
	public void tirada(int i){
		tiradas--;
		if (tablero.getCasillas()[i] instanceof Casilla_Multiplica) 
			puntos = puntos*2;
		else if(tablero.getCasillas()[i] instanceof Casilla_Especial) { 
			tiradas++;
		}
		puntos += tablero.getCasillas()[i].getPuntos();
	}
	
	public boolean isPartidaFinalizada() {
		return tiradas == 0;
	}

//	public String getCausaFin() {
//		if(invasorEncontrado)
//			return "Se ha encontrado el invasor.";
//		else if( meteoritoEncontrado)
//			return "Te has estrellado contra un meteorito.";
//		else if(disparos==0)
//			return "No te quedan disparos.";
//		else 
//			return null;
//	}
	
	public int getPuntos() {
		return puntos;
	}

}
