package logica;

import java.util.*;

public class Carta {

	private static final String FICHERO_ARTICULOS = "files/articulos.dat";
	private List<Articulo> listaArticulos = null;

	public Carta() {
		listaArticulos = new ArrayList<Articulo>();
		cargarArticulos();
	}

	private void cargarArticulos() {
		FileUtil.loadFile(FICHERO_ARTICULOS, listaArticulos);
	}

	public Articulo[] getArticulos() {
		Articulo[] articulos = listaArticulos.toArray(new Articulo[listaArticulos.size()]);
		return articulos;
	}

	public List<Articulo> getListaArticulos() {
		return listaArticulos;
	}
	
	public List<Articulo> getListaArticulos(String tipo){
		List<Articulo> ret = new LinkedList<Articulo>();
		for(Articulo articulo: listaArticulos) {
			if(articulo.getTipo().equals(tipo))
				ret.add(articulo);
		}
		return ret;
	}

}
