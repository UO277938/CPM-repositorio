package logica;

public class Tablero {
	
	public static final int DIM = 8;
	Casilla[] casillas;
	
	public Tablero() {
		casillas = new Casilla[DIM];
		for (int i=0;i<DIM;i++)
			casillas[i] = new Espacio();
		int posInvasor = colocaInvasor();
		colocaMeteorito(posInvasor);
	}

	private void colocaMeteorito(int posInvasor) {
		int posMeteorito= posInvasor;
		while(posInvasor==posMeteorito) 
			posMeteorito = (int) (Math.random()* DIM);
		System.out.println("Meteorito en: "+ posMeteorito);
		casillas[posMeteorito] = new Meteorito();
	}

	private int colocaInvasor() {
		int posicionInvasor = (int) (Math.random() * DIM);
		System.out.println("Invasor en: "+ posicionInvasor);
		casillas[posicionInvasor] = new Invasor();	
		return posicionInvasor;
	}

	public Casilla[] getCasillas() {
		return casillas;
	}
}
