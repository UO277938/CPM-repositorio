package logica;

public class Meteorito extends Casilla{
	
	public Meteorito() {
		setPuntos(0);
	}

}
