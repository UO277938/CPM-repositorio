package logica;

public class Dado {
	
	public static int lanzar()
	{ 
		return ((int) (Math.random() * Juego.maxDisparos) + 1);
	}
}
