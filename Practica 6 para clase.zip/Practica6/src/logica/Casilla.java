package logica;

public abstract class Casilla {
	
	private int puntos;
	
	public int getPuntos() {
		return puntos;
	}
	
	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}
}
