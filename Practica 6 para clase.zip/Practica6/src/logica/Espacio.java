package logica;

public class Espacio extends Casilla {

	public Espacio() {
		setPuntos(-200);
	}
}