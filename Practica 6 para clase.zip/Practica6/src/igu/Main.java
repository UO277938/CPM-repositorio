package igu;

import java.awt.EventQueue;
import java.util.Properties;

import javax.swing.UIManager;

import com.jtattoo.plaf.hifi.HiFiLookAndFeel;

import logica.Juego;

public class Main {

	public static void main(String[] args) {
		Juego juego = new Juego();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Properties props = new Properties();
					props.put("logoString", "");
					HiFiLookAndFeel.setCurrentTheme(props);
					UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
					VentanaPrincipal vp = new VentanaPrincipal(juego);
					vp.setVisible(true);
					vp.setBounds(100,100,850,450);
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

}
