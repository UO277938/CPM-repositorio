package igu;

import java.awt.BorderLayout;

import javax.help.*;
import java.net.*;
import java.io.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.Color;
import javax.swing.border.EtchedBorder;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JSlider;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.border.LineBorder;

import player.MusicPlayer;
import player.MyFile;

import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.event.ChangeEvent;


public class VentanaPrincipal extends JFrame {

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnFile;
	private JMenu mnPlay;
	private JMenu mnOptions;
	private JMenu mnHelp;
	private JMenuItem itOpen;
	private JMenuItem itExit;
	private JSeparator separator;
	private JMenuItem itNext;
	private JMenuItem itRandom;
	private JMenuItem itContents;
	private JMenuItem itAbout;
	private JSeparator separator_1;
	private JPanel pnNorte;
	private JPanel pnCentro;
	private JPanel pnSur;
	private JLabel lbLogo;
	private JSlider slVolumen;
	private JLabel lbVolumen;
	private JTextField txVolumen;
	private JPanel pnVolumen;
	private JLabel lbReproduciendo;
	private JPanel pnLibrary;
	private JPanel pnPlay;
	private JLabel lbLibrary;
	private JPanel pnBtLibrary;
	private JScrollPane scListLibrary;
	private JScrollPane scPlayList;
	
	private JList<MyFile> listLibrary;
	private JList<MyFile> listPlay;
	private DefaultListModel<MyFile> modelListLibrary;
	private DefaultListModel<MyFile> modelListPlay;
	
	private JLabel lbPlay;
	private JButton btAdd;
	private JButton btDelLib;
	private JPanel pnBtPlay;
	private JButton btRewind;
	private JButton btPlay;
	private JButton btStop;
	private JButton btForward;
	private JButton btDelPlay;
	private JFileChooser selector;

	private MusicPlayer mP;
	private JButton btEmpty;
	private JButton btDelAll;

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal(MusicPlayer mP) {
		this.mP = mP;
		cargaAyuda();
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/logoTitulo.png")));
		setTitle("EII Music Player");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 830, 586);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(getPnNorte(), BorderLayout.NORTH);
		contentPane.add(getPnCentro(), BorderLayout.CENTER);
		contentPane.add(getPnSur(), BorderLayout.SOUTH);
		setLocationRelativeTo(null);
	}

	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnFile());
			menuBar.add(getMnPlay());
			menuBar.add(getMnOptions());
			menuBar.add(getMnHelp());
		}
		return menuBar;
	}
	private JMenu getMnFile() {
		if (mnFile == null) {
			mnFile = new JMenu("File");
			mnFile.setMnemonic('F');
			mnFile.add(getItOpen());
			mnFile.add(getSeparator());
			mnFile.add(getItExit());
		}
		return mnFile;
	}
	private JMenu getMnPlay() {
		if (mnPlay == null) {
			mnPlay = new JMenu("Play");
			mnPlay.setMnemonic('Y');
			mnPlay.add(getItNext());
		}
		return mnPlay;
	}
	private JMenu getMnOptions() {
		if (mnOptions == null) {
			mnOptions = new JMenu("Options");
			mnOptions.setMnemonic('O');
			mnOptions.add(getItRandom());
		}
		return mnOptions;
	}
	private JMenu getMnHelp() {
		if (mnHelp == null) {
			mnHelp = new JMenu("Help");
			mnHelp.setMnemonic('H');
			mnHelp.add(getItContents());
			mnHelp.add(getSeparator_1());
			mnHelp.add(getItAbout());
		}
		return mnHelp;
	}
	private JMenuItem getItOpen() {
		if (itOpen == null) {
			itOpen = new JMenuItem("Open");
			itOpen.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					cargarFicheros();
				}
			});
			itOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
		}
		return itOpen;
	}
	private JMenuItem getItExit() {
		if (itExit == null) {
			itExit = new JMenuItem("Exit");
			itExit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					System.exit(0);
				}
			});
		}
		return itExit;
	}
	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}
	private JMenuItem getItNext() {
		if (itNext == null) {
			itNext = new JMenuItem("Next");
			itNext.setEnabled(false);
		}
		return itNext;
	}
	private JMenuItem getItRandom() {
		if (itRandom == null) {
			itRandom = new JMenuItem("Random");
			itRandom.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					escucharAleatoria();
				}
			});
			itRandom.setEnabled(false);
		}
		return itRandom;
	}
	private JMenuItem getItContents() {
		if (itContents == null) {
			itContents = new JMenuItem("Contents");
			itContents.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
		}
		return itContents;
	}
	private JMenuItem getItAbout() {
		if (itAbout == null) {
			itAbout = new JMenuItem("About");
			itAbout.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
		}
		return itAbout;
	}
	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
	private JPanel getPnNorte() {
		if (pnNorte == null) {
			pnNorte = new JPanel();
			pnNorte.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			pnNorte.setBackground(Color.BLACK);
			pnNorte.setLayout(new GridLayout(1, 3, 0, 0));
			pnNorte.add(getLbLogo());
			pnNorte.add(getSlVolumen());
			pnNorte.add(getPnVolumen());
		}
		return pnNorte;
	}
	private JPanel getPnCentro() {
		if (pnCentro == null) {
			pnCentro = new JPanel();
			pnCentro.setLayout(new GridLayout(0, 2, 4, 0));
			pnCentro.add(getPnLibrary());
			pnCentro.add(getPnPlay());
		}
		return pnCentro;
	}
	private JPanel getPnSur() {
		if (pnSur == null) {
			pnSur = new JPanel();
			pnSur.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
			pnSur.add(getLbReproduciendo());
		}
		return pnSur;
	}
	private JLabel getLbLogo() {
		if (lbLogo == null) {
			lbLogo = new JLabel("");
			lbLogo.setBackground(Color.BLACK);
			lbLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/logo.png")));
		}
		return lbLogo;
	}
	private JSlider getSlVolumen() {
		if (slVolumen == null) {
			slVolumen = new JSlider();
			slVolumen.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					getTxVolumen().setText(String.valueOf(getSlVolumen().getValue()));
					mP.setVolume(getSlVolumen().getValue(), getSlVolumen().getMaximum());
				}
			});
			slVolumen.setFocusable(false);
			slVolumen.setForeground(Color.WHITE);
			slVolumen.setPaintLabels(true);
			slVolumen.setPaintTicks(true);
			slVolumen.setMinorTickSpacing(10);
			slVolumen.setMajorTickSpacing(20);
			slVolumen.setBackground(Color.BLACK);
		}
		return slVolumen;
	}
	private JLabel getLbVolumen() {
		if (lbVolumen == null) {
			lbVolumen = new JLabel("Vol:");
			lbVolumen.setHorizontalAlignment(SwingConstants.RIGHT);
			lbVolumen.setFont(new Font("Dialog", Font.BOLD, 40));
			lbVolumen.setForeground(new Color(255, 99, 71));
			lbVolumen.setBackground(Color.BLACK);
		}
		return lbVolumen;
	}
	private JTextField getTxVolumen() {
		if (txVolumen == null) {
			txVolumen = new JTextField();
			txVolumen.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					comprobarVolumen();
				}
			});
			txVolumen.setHorizontalAlignment(SwingConstants.LEFT);
			txVolumen.setForeground(new Color(255, 255, 255));
			txVolumen.setBackground(new Color(0, 0, 0));
			txVolumen.setFont(new Font("Dialog", Font.BOLD, 40));
			txVolumen.setText("50");
			txVolumen.setColumns(10);
		}
		return txVolumen;
	}
	private void comprobarVolumen() {
		if (Integer.parseInt(getTxVolumen().getText())>100) {
			getTxVolumen().setText("100");
			getSlVolumen().setValue(100);
		}
		else if (Integer.parseInt(getTxVolumen().getText())<0) {
			getTxVolumen().setText("0");
			getSlVolumen().setValue(0);
		}
		else {
			getSlVolumen().setValue(Integer.parseInt(getTxVolumen().getText()));
		}
	}
	
	private JPanel getPnVolumen() {
		if (pnVolumen == null) {
			pnVolumen = new JPanel();
			pnVolumen.setBackground(new Color(0, 0, 0));
			pnVolumen.setLayout(new GridLayout(0, 2, 0, 0));
			pnVolumen.add(getLbVolumen());
			pnVolumen.add(getTxVolumen());
		}
		return pnVolumen;
	}
	private JLabel getLbReproduciendo() {
		if (lbReproduciendo == null) {
			lbReproduciendo = new JLabel("Reproduciendo...");
		}
		return lbReproduciendo;
	}
	private JPanel getPnLibrary() {
		if (pnLibrary == null) {
			pnLibrary = new JPanel();
			pnLibrary.setBackground(new Color(0, 0, 0));
			pnLibrary.setLayout(new BorderLayout(0, 0));
			pnLibrary.add(getLbLibrary(), BorderLayout.NORTH);
			pnLibrary.add(getPnBtLibrary(), BorderLayout.SOUTH);
			pnLibrary.add(getScListLibrary());
		}
		return pnLibrary;
	}
	private JPanel getPnPlay() {
		if (pnPlay == null) {
			pnPlay = new JPanel();
			pnPlay.setBackground(Color.BLACK);
			pnPlay.setLayout(new BorderLayout(0, 0));
			pnPlay.add(getLbPlay(), BorderLayout.NORTH);
			pnPlay.add(getScPlayList(), BorderLayout.CENTER);
			pnPlay.add(getPnBtPlay(), BorderLayout.SOUTH);
		}
		return pnPlay;
	}
	private JLabel getLbLibrary() {
		if (lbLibrary == null) {
			lbLibrary = new JLabel("\u266aLibrary:");
			lbLibrary.setLabelFor(getListLibrary());
			lbLibrary.setDisplayedMnemonic('L');
			lbLibrary.setForeground(new Color(255, 140, 0));
			lbLibrary.setFont(new Font("Dialog", Font.BOLD, 18));
		}
		return lbLibrary;
	}
	private JPanel getPnBtLibrary() {
		if (pnBtLibrary == null) {
			pnBtLibrary = new JPanel();
			pnBtLibrary.setBackground(new Color(0, 0, 0));
			pnBtLibrary.setLayout(new GridLayout(0, 3, 0, 0));
			pnBtLibrary.add(getBtAdd());
			pnBtLibrary.add(getBtDelLib());
			pnBtLibrary.add(getBtDelAll());
		}
		return pnBtLibrary;
	}
	private JScrollPane getScListLibrary() {
		if (scListLibrary == null) {
			scListLibrary = new JScrollPane();
			scListLibrary.setBorder(new LineBorder(new Color(255, 99, 71), 5));
			scListLibrary.setViewportView(getListLibrary());
		}
		return scListLibrary;
	}
	private JButton getBtAdd() {
		if (btAdd == null) {
			btAdd = new JButton("Add To PlayList");
			btAdd.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					añadirListPlay();
				}
			});
			btAdd.setMnemonic('A');
			btAdd.setFont(new Font("Tahoma", Font.BOLD, 12));
		}
		return btAdd;
	}
	private JList<MyFile> getListLibrary() {
		if (listLibrary == null) {
			modelListLibrary = new DefaultListModel<MyFile>();
			listLibrary = new JList<MyFile>(modelListLibrary); //IMPORTANTE ASOCIAR EL MODELO CON LA LISTA
			listLibrary.setBackground(new Color(0, 0, 0));
		}
		return listLibrary;
	}
	private JList<MyFile> getListPlay() {
		if (listPlay == null) {
			modelListPlay = new DefaultListModel<MyFile>();
			listPlay = new JList<MyFile>();
			listPlay.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			listPlay.setModel(modelListPlay); //IMPORTANTE: asociar MODELO_LISTA
			listPlay.setBackground(Color.BLACK);
		}
		return listPlay;
	}

	private JLabel getLbPlay() {
		if (lbPlay == null) {
			lbPlay = new JLabel("♪Play:");
			lbPlay.setLabelFor(getListPlay());
			lbPlay.setDisplayedMnemonic('P');
			lbPlay.setForeground(new Color(255, 140, 0));
			lbPlay.setFont(new Font("Dialog", Font.BOLD, 18));
		}
		return lbPlay;
	}
	private JScrollPane getScPlayList() {
		if (scPlayList == null) {
			scPlayList = new JScrollPane();
			scPlayList.setBorder(new LineBorder(new Color(255, 99, 71), 5));
			scPlayList.setViewportView(getListPlay());
		}
		return scPlayList;
	}
	private JButton getBtDelLib() {
		if (btDelLib == null) {
			btDelLib = new JButton("Delete");
			btDelLib.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					borrarListLibrary();
				}
			});
			btDelLib.setMnemonic('D');
			btDelLib.setFont(new Font("Tahoma", Font.BOLD, 12));
		}
		return btDelLib;
	}
	private JPanel getPnBtPlay() {
		if (pnBtPlay == null) {
			pnBtPlay = new JPanel();
			pnBtPlay.setBackground(Color.BLACK);
			pnBtPlay.setLayout(new GridLayout(0, 3, 0, 0));
			pnBtPlay.add(getBtRewind());
			pnBtPlay.add(getBtPlay());
			pnBtPlay.add(getBtStop());
			pnBtPlay.add(getBtForward());
			pnBtPlay.add(getBtDelPlay());
			pnBtPlay.add(getBtEmpty());
		}
		return pnBtPlay;
	}
	private JButton getBtRewind() {
		if (btRewind == null) {
			btRewind = new JButton("◄◄");
			btRewind.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int indiceSeleccionado = getListPlay().getSelectedIndex();
					
					if (indiceSeleccionado != 0)
						getListPlay().setSelectedIndex(indiceSeleccionado-1);
					
					mP.play(getListPlay().getSelectedValue().getF());
				}
			});
			btRewind.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btRewind.setToolTipText("Rewind");
		}
		return btRewind;
	}
	private JButton getBtPlay() {
		if (btPlay == null) {
			btPlay = new JButton("►");
			btPlay.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (getListPlay().getSelectedIndex() == -1)//indica si hay algun elemento seleccionado en el JList
						getListPlay().setSelectedIndex(0);
					mP.play(getListPlay().getSelectedValue().getF());
					mP.setVolume(getSlVolumen().getValue(),getSlVolumen().getMaximum());
				}
			});
			btPlay.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btPlay.setToolTipText("Play");
		}
		return btPlay;
	}
	private JButton getBtStop() {
		if (btStop == null) {
			btStop = new JButton("■");
			btStop.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mP.stop();
				}
			});
			btStop.setFont(new Font("Tahoma", Font.PLAIN, 12));
			btStop.setToolTipText("Stop");
		}
		return btStop;
	}
	private JButton getBtForward() {
		if (btForward == null) {
			btForward = new JButton("►►");
			btForward.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int indiceSeleccionado = getListPlay().getSelectedIndex();
					int indiceMaximo = getListPlay().getModel().getSize();
					if (indiceSeleccionado != indiceMaximo)
						getListPlay().setSelectedIndex(indiceSeleccionado+1);
					
					mP.play(getListPlay().getSelectedValue().getF());
				}
			});
			btForward.setToolTipText("Forward");
		}
		return btForward;
	}
	private JButton getBtDelPlay() {
		if (btDelPlay == null) {
			btDelPlay = new JButton("Delete");
			btDelPlay.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mP.stop();
					modelListPlay.removeElement(getListPlay().getSelectedValue());
					comprobarVacia();
				}
			});
			btDelPlay.setMnemonic('T');
			btDelPlay.setFont(new Font("Tahoma", Font.BOLD, 12));
		}
		return btDelPlay;
	}
	
	private void comprobarVacia() {
		if (getListPlay().getModel().getSize() == 0)
			getItRandom().setEnabled(false);
	}
	
	private void cargaAyuda(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"introduccion", hs); //activar F1
		   hb.enableHelpOnButton(getItContents(), "introduccion", hs);
		   
		   hb.enableHelp(getBtAdd(), "anadir", hs); //ayuda contextual
		   hb.enableHelp(getBtDelLib(), "eliminar", hs);
		   hb.enableHelp(getBtPlay(), "reproducir", hs);
		   hb.enableHelp(getSlVolumen(), "volumen", hs);
		   hb.enableHelp(getTxVolumen(), "volumen", hs);
		 }
	
	private JFileChooser getSelector() {
		if (selector == null) {
			selector = new JFileChooser();
			selector.setMultiSelectionEnabled(true);
			selector.setFileFilter(new FileNameExtensionFilter("Archivos mp3","mp3"));
			selector.setFileFilter(new FileNameExtensionFilter("Archivos mp4","mp4"));
			//String path = System.getProperty("user.dir");	//Accede al directorio donde estoy ejecutando la aplicacion
			String path = System.getProperty("user.home")+"/desktop";
			selector.setCurrentDirectory(new File(path));
		}
		
		return selector;
	}
	
	private void cargarFicheros() {
		if (getSelector().showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			
			for (int i=0; i<getSelector().getSelectedFiles().length; i++) {
				File file = getSelector().getSelectedFiles()[i];
				if (!isInList(getListLibrary(),file))
					modelListLibrary.addElement(new MyFile(getSelector().getSelectedFiles()[i]));
			}
		}
	}
	
	private void añadirListPlay() {
		
		for (int i=0; i<getListLibrary().getSelectedValuesList().size() ; i++) {
			MyFile file = getListLibrary().getSelectedValuesList().get(i);
			if (!isInList(getListPlay(),file.getF())) {
				modelListPlay.addElement(getListLibrary().getSelectedValuesList().get(i));
				getItRandom().setEnabled(true);
			}
		}
	}
	
	private boolean isInList(JList<MyFile> lista, File file) {
		for (int i = 0; i<lista.getModel().getSize(); i++) {
			if (lista.getModel().getElementAt(i).getF().equals(file))
				return true;
		}
		return false;
		
	}
	
	private void borrarListLibrary() {
		
		java.util.List<MyFile> cancionesBorrar = getListLibrary().getSelectedValuesList();
		
		for (int i=0; i<cancionesBorrar.size() ; i++) {
			modelListLibrary.removeElement(cancionesBorrar.get(i));
		}
//		OPCION NO VALIDA		
//		for (int i=0; i<getListLibrary().getSelectedValuesList().size() ; i++) {
//			modelListLibrary.removeElement(getListLibrary().getSelectedValuesList().get(i));
//		}
	}
	
	private void escucharAleatoria() {
		int i = (int) Math.random() * getListPlay().getModel().getSize();
		if (!(getListPlay().getModel().getSize() == 0)) {
			getListPlay().setSelectedIndex(i);
			mP.play(getListPlay().getSelectedValue().getF());
		}
		
	}

	private JButton getBtEmpty() {
		if (btEmpty == null) {
			btEmpty = new JButton("Delete all");
			btEmpty.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					modelListPlay = new DefaultListModel<MyFile>();
					getListPlay().setModel(modelListPlay);
					getItRandom().setEnabled(false);
				}
			});
			btEmpty.setFont(new Font("Tahoma", Font.BOLD, 12));
		}
		return btEmpty;
	}
	private JButton getBtDelAll() {
		if (btDelAll == null) {
			btDelAll = new JButton("Delete all");
			btDelAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					modelListLibrary = new DefaultListModel<MyFile>();
					getListLibrary().setModel(modelListLibrary);
				}
			});
			btDelAll.setFont(new Font("Tahoma", Font.BOLD, 12));
		}
		return btDelAll;
	}
}
