package logica;

public class Invasor extends Casilla {

	public Invasor() {
		setPuntos(3000);
	}
}
