package igu;

import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import javax.swing.border.LineBorder;

import logica.Juego;
import logica.Tablero;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaPrincipal extends JFrame {
	private JLabel lbNave;
	private JLabel lbEarth;
	private JButton btDado;
	private JTextField txtPuntos;
	private JLabel lbPuntos;
	private JPanel pnDisparos;
	private JPanel pnTablero;
	private JButton bt7;
	private JButton bt6;
	private JButton bt5;
	private JButton bt4;
	private JButton bt3;
	private JButton bt2;
	private JButton bt1;
	private JButton bt0;
	
	private Juego juego;
	
	
	public VentanaPrincipal(Juego juego) {
		this.juego=juego;
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/invader.jpg")));
		setTitle("Marcianitos");
		getContentPane().setBackground(Color.BLACK);
		getContentPane().setLayout(null);
		getContentPane().add(getLbNave());
		getContentPane().add(getLbEarth());
		getContentPane().add(getBtDado());
		getContentPane().add(getTxtPuntos());
		getContentPane().add(getLbPuntos());
		getContentPane().add(getPnDisparos());
		getContentPane().add(getPnTablero());
	}

	private JLabel getLbNave() {
		if (lbNave == null) {
			lbNave = new JLabel("");
			lbNave.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/spaceship.png")));
			lbNave.setBounds(263, 37, 134, 86);
		}
		return lbNave;
	}
	
	private JLabel getLbEarth() {
		if (lbEarth == null) {
			lbEarth = new JLabel("");
			lbEarth.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/earth.jpg")));
			lbEarth.setBounds(585, 11, 193, 175);
		}
		return lbEarth;
	}
	
	private JButton getBtDado() {
		if (btDado == null) {
			btDado = new JButton("");
			btDado.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					iniciarJuego();
				}
			});
			btDado.setDisabledIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/dice.jpg")));
			btDado.setBorder(null);
			btDado.setBorderPainted(false);
			btDado.setBackground(Color.BLACK);
			btDado.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/dice.jpg")));
			btDado.setBounds(10, 11, 109, 112);
		}
		return btDado;
	}
	
	private void iniciarJuego() {
		juego.lanzar();
		actualizarPuntos();
		pintarDisparos();
		habiliatarTablero(true);
		getBtDado().setEnabled(false);
	}
	
	private void actualizarPuntos() {
		getTxtPuntos().setText(Integer.toString(juego.getPuntos()));
	}

	private void pintarDisparos() {
		for(int i=0;i<juego.getDisparos();i++) 
			getPnDisparos().add(nuevoDisparo());
		validate();		
	}

	private Component nuevoDisparo() {
		JLabel nuevo = new JLabel();
		nuevo.setIcon(ImagenFactoria.getImagen());
		nuevo.setBorder(new LineBorder(Color.green,1));
		return nuevo;
	}

	private void habiliatarTablero(boolean estado) {
		for(int i=0;i<getPnTablero().getComponents().length;i++) 
			getPnTablero().getComponents()[i].setEnabled(estado);
	}
	
	private JTextField getTxtPuntos() {
		if (txtPuntos == null) {
			txtPuntos = new JTextField();
			txtPuntos.setHorizontalAlignment(SwingConstants.CENTER);
			txtPuntos.setText("0");
			txtPuntos.setBorder(null);
			txtPuntos.setForeground(Color.GREEN);
			txtPuntos.setFont(new Font("Tahoma", Font.PLAIN, 30));
			txtPuntos.setBackground(Color.BLACK);
			txtPuntos.setEditable(false);
			txtPuntos.setBounds(489, 81, 86, 42);
			txtPuntos.setColumns(10);
		}
		return txtPuntos;
	}
	
	private JLabel getLbPuntos() {
		if (lbPuntos == null) {
			lbPuntos = new JLabel("Puntos:");
			lbPuntos.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lbPuntos.setForeground(Color.WHITE);
			lbPuntos.setBounds(489, 42, 86, 28);
		}
		return lbPuntos;
	}
	private JPanel getPnDisparos() {
		if (pnDisparos == null) {
			pnDisparos = new JPanel();
			pnDisparos.setBackground(new Color(0, 0, 0));
			pnDisparos.setBounds(140, 147, 435, 105);
			pnDisparos.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		}
		return pnDisparos;
	}
	
	private JPanel getPnTablero() {
		if (pnTablero == null) {
			pnTablero = new JPanel();
			pnTablero.setBorder(new LineBorder(new Color(255, 69, 0), 5));
			pnTablero.setBackground(new Color(255, 69, 0));
			pnTablero.setBounds(23, 302, 735, 96);
			pnTablero.setLayout(new GridLayout(1, 8, 5, 0));
			pnTablero.add(getBt0());
			pnTablero.add(getBt1());
			pnTablero.add(getBt2());
			pnTablero.add(getBt3());
			pnTablero.add(getBt4());
			pnTablero.add(getBt5());
			pnTablero.add(getBt6());
			pnTablero.add(getBt7());
		}
		return pnTablero;
	}
	
	private JButton getBt7() {
		if (bt7 == null) {
			bt7 = new JButton("");
			bt7.setEnabled(false);
			bt7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(7);
				}
			});
			bt7.setBackground(new Color(0, 0, 0));
			bt7.setForeground(Color.BLACK);
		}
		return bt7;
	}
	
	private JButton getBt6() {
		if (bt6 == null) {
			bt6 = new JButton("");
			bt6.setEnabled(false);
			bt6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(6);
				}
			});
			bt6.setBackground(new Color(0, 0, 0));
			bt6.setForeground(Color.BLACK);
		}
		return bt6;
	}
	
	private JButton getBt5() {
		if (bt5 == null) {
			bt5 = new JButton("");
			bt5.setEnabled(false);
			bt5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(5);
				}
			});
			bt5.setBackground(new Color(0, 0, 0));
			bt5.setForeground(Color.BLACK);
		}
		return bt5;
	}
	
	private JButton getBt4() {
		if (bt4 == null) {
			bt4 = new JButton("");
			bt4.setEnabled(false);
			bt4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(4);
				}
			});
			bt4.setBackground(new Color(0, 0, 0));
			bt4.setForeground(Color.BLACK);
		}
		return bt4;
	}
	private JButton getBt3() {
		if (bt3 == null) {
			bt3 = new JButton("");
			bt3.setEnabled(false);
			bt3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(3);
				}
			});
			bt3.setBackground(new Color(0, 0, 0));
			bt3.setForeground(Color.BLACK);
		}
		return bt3;
	}
	
	private JButton getBt2() {
		if (bt2 == null) {
			bt2 = new JButton("");
			bt2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(2);
				}
			});
			bt2.setEnabled(false);
			bt2.setBackground(new Color(0, 0, 0));
			bt2.setForeground(Color.BLACK);
		}
		return bt2;
	}
	private JButton getBt1() {
		if (bt1 == null) {
			bt1 = new JButton("");
			bt1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(1);
				}
			});
			bt1.setEnabled(false);
			bt1.setBackground(new Color(0, 0, 0));
			bt1.setForeground(Color.BLACK);
		}
		return bt1;
	}
	
	private JButton getBt0() {
		if (bt0 == null) {
			bt0 = new JButton("");
			bt0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					disparar(0);
				}
			});
			bt0.setEnabled(false);
			bt0.setBackground(new Color(0, 0, 0));
			bt0.setForeground(Color.BLACK);
		}
		return bt0;
	}
	
	private void disparar(int i) {
		juego.dispara(i);
		representaJuego(i);
	}
	
	private void representaJuego(int i) {
		pintaPuntos();
		despintaDisparo();
		pintaCasilla(i);
		compruebaFin();
		deshabilitaBoton(i);
	}

	private void pintaPuntos() {
		getTxtPuntos().setText(String.valueOf(juego.getPuntos()));
	}
	
	private void despintaDisparo() {
		getPnDisparos().remove(0);
		getPnDisparos().repaint();
	}
	
	private void pintaCasilla(int i) {
		ImageIcon imagen = ImagenFactoria.getImagen(juego.getTablero().getCasillas()[i]);
		((JButton)getPnTablero().getComponent(i)).setIcon(imagen);
		((JButton)getPnTablero().getComponent(i)).setDisabledIcon(imagen);
	}
	
	private void compruebaFin() {
		if (juego.isPartidaFinalizada()){
			habiliatarTablero(false);
			JOptionPane.showMessageDialog(null, "Partida finalizada", "Invasi�n espacial", JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	private void deshabilitaBoton(int i) {
		((JButton)getPnTablero().getComponent(i)).setEnabled(false);
	}
	
}
