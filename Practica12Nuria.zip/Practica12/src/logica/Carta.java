package logica;

import java.util.*;

public class Carta {

	private static final String FICHERO_ARTICULOS = "files/articulos.dat";
	private List<Articulo> listaArticulos = null;

	public Carta() {
		listaArticulos = new ArrayList<Articulo>();
		cargarArticulos();
	}

	private void cargarArticulos() {
		FileUtil.loadFile(FICHERO_ARTICULOS, listaArticulos);
	}

	public Articulo[] getArticulos() {
		Articulo[] articulos = listaArticulos.toArray(new Articulo[listaArticulos.size()]);
		return articulos;
	}
	
//	public Articulo[] getHamburguesas() {
//		List<Articulo> articulosList = new ArrayList<Articulo>();
//		
//		for (Articulo a : listaArticulos) {
//			if (a.getTipo().equals("Hamburguesa"))
//				articulosList.add(a);
//		}
//		Articulo[] articulos = articulosList.toArray(new Articulo[listaArticulos.size()]);
//		return articulos;
//	}
//	
//	public Articulo[] getBebidas() {
//		List<Articulo> articulosList = new ArrayList<Articulo>();
//		
//		for (Articulo a : listaArticulos) {
//			if (a.getTipo().equals("Bebida"))
//				articulosList.add(a);
//		}
//		Articulo[] articulos = articulosList.toArray(new Articulo[listaArticulos.size()]);
//		return articulos;
//	}
//	
//	public Articulo[] getComplementos() {
//		List<Articulo> articulosList = new ArrayList<Articulo>();
//		
//		for (Articulo a : listaArticulos) {
//			if (a.getTipo().equals("Complemento"))
//				articulosList.add(a);
//		}
//		Articulo[] articulos = articulosList.toArray(new Articulo[listaArticulos.size()]);
//		return articulos;
//	}
//	
//	public Articulo[] getPostres() {
//		List<Articulo> articulosList = new ArrayList<Articulo>();
//		
//		for (Articulo a : listaArticulos) {
//			if (a.getTipo().equals("Postre"))
//				articulosList.add(a);
//		}
//		Articulo[] articulos = articulosList.toArray(new Articulo[listaArticulos.size()]);
//		return articulos;
//	}

	public List<Articulo> getListaArticulos() {
		return listaArticulos;
	}

}
